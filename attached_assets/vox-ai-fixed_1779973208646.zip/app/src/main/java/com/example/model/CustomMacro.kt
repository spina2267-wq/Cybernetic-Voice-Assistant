package com.example.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class CustomMacro(
    val id: String,
    val triggerPhrase: String, // e.g., "abre modo juego" or "buenos días"
    val commands: List<String>, // e.g., ["pon música de gaming", "abre la app subway surfers"]
    val isEnabled: Boolean = true
)
