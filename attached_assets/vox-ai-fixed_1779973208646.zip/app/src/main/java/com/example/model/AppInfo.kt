package com.example.model

data class AppInfo(
    val name: String,
    val packageName: String
)
