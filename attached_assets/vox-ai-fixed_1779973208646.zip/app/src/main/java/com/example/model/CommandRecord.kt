package com.example.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class CommandRecord(
    val id: String,
    val rawText: String,
    val parsedAction: String,
    val timestamp: Long,
    val success: Boolean = false,
    val speechReply: String
)
