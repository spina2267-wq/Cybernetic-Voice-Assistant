package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.AssistantRepository
import com.example.api.DiscordWebhookSender
import com.example.model.AssistantAction
import com.example.model.CommandRecord
import com.example.model.ParsedResponse
import com.example.model.AppInfo
import com.example.model.Routine
import com.example.model.CustomMacro
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID
import java.util.Date
import java.text.SimpleDateFormat

class AssistantViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val repository = AssistantRepository()
    private val sharedPrefs = application.getSharedPreferences("assistant_prefs", Context.MODE_PRIVATE)
    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()
    
    // Command logs adapter
    private val commandListAdapterType: java.lang.reflect.Type = Types.newParameterizedType(List::class.java, CommandRecord::class.java)
    private val commandListAdapter: com.squareup.moshi.JsonAdapter<List<CommandRecord>> = moshi.adapter(commandListAdapterType)

    // Voice shortcuts adapter
    private val shortcutsAdapterType: java.lang.reflect.Type = Types.newParameterizedType(Map::class.java, String::class.java, String::class.java)
    private val shortcutsAdapter: com.squareup.moshi.JsonAdapter<Map<String, String>> = moshi.adapter(shortcutsAdapterType)

    // Routine adapters
    private val routineListAdapterType: java.lang.reflect.Type = Types.newParameterizedType(List::class.java, Routine::class.java)
    private val routineListAdapter: com.squareup.moshi.JsonAdapter<List<Routine>> = moshi.adapter(routineListAdapterType)

    // Custom Macro adapters
    private val customMacroListAdapterType: java.lang.reflect.Type = Types.newParameterizedType(List::class.java, CustomMacro::class.java)
    private val customMacroListAdapter: com.squareup.moshi.JsonAdapter<List<CustomMacro>> = moshi.adapter(customMacroListAdapterType)

    // UI States
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isContinuousListening = MutableStateFlow(false)
    val isContinuousListening: StateFlow<Boolean> = _isContinuousListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _triggerWord = MutableStateFlow("asistente")
    val triggerWord: StateFlow<String> = _triggerWord.asStateFlow()

    private val _discordWebhook = MutableStateFlow("")
    val discordWebhook: StateFlow<String> = _discordWebhook.asStateFlow()

    private val _ttsEnabled = MutableStateFlow(true)
    val ttsEnabled: StateFlow<Boolean> = _ttsEnabled.asStateFlow()

    private val _statusText = MutableStateFlow("Di: \"asistente\" y tu comando...")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _lastResultSpeech = MutableStateFlow("")
    val lastResultSpeech: StateFlow<String> = _lastResultSpeech.asStateFlow()

    private val _commandsHistory = MutableStateFlow<List<CommandRecord>>(emptyList())
    val commandsHistory: StateFlow<List<CommandRecord>> = _commandsHistory.asStateFlow()

    private val _voiceShortcuts = MutableStateFlow<Map<String, String>>(emptyMap())
    val voiceShortcuts: StateFlow<Map<String, String>> = _voiceShortcuts.asStateFlow()

    // Flag to trigger real-time listening sessions
    private val _speechRecognitionTrigger = MutableStateFlow<Long?>(null)
    val speechRecognitionTrigger: StateFlow<Long?> = _speechRecognitionTrigger.asStateFlow()

    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    // Voice print biometric settings states
    private val _voiceIdEnabled = MutableStateFlow(false)
    val voiceIdEnabled: StateFlow<Boolean> = _voiceIdEnabled.asStateFlow()

    private val _voiceIdRegistered = MutableStateFlow(false)
    val voiceIdRegistered: StateFlow<Boolean> = _voiceIdRegistered.asStateFlow()

    private val _voiceIdCalibrationStep = MutableStateFlow(0) // 0: inactive, 1, 2, 3 calibration steps
    val voiceIdCalibrationStep: StateFlow<Int> = _voiceIdCalibrationStep.asStateFlow()

    private val _voiceOwnerName = MutableStateFlow("Salva")
    val voiceOwnerName: StateFlow<String> = _voiceOwnerName.asStateFlow()

    private val _simulateIntruder = MutableStateFlow(false)
    val simulateIntruder: StateFlow<Boolean> = _simulateIntruder.asStateFlow()

    private val _routines = MutableStateFlow<List<Routine>>(emptyList())
    val routines: StateFlow<List<Routine>> = _routines.asStateFlow()

    private val _customMacros = MutableStateFlow<List<CustomMacro>>(emptyList())
    val customMacros: StateFlow<List<CustomMacro>> = _customMacros.asStateFlow()

    fun saveRoutines() {
        try {
            val json = routineListAdapter.toJson(_routines.value)
            sharedPrefs.edit().putString("custom_routines", json).apply()
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error saving routines", e)
        }
    }

    fun loadRoutines() {
        try {
            val json = sharedPrefs.getString("custom_routines", null)
            if (json != null) {
                val list = routineListAdapter.fromJson(json) ?: emptyList()
                _routines.value = list
            } else {
                // Initialize clean robust defaults!
                val defaultRoutines = listOf(
                    Routine(
                        id = UUID.randomUUID().toString(),
                        name = "Resumen Diario de Gmail",
                        executeTime = "15:00",
                        command = "Revisa mi Gmail y hazme un resumen",
                        isEnabled = true
                    ),
                    Routine(
                        id = UUID.randomUUID().toString(),
                        name = "Notificación Diaria",
                        executeTime = "09:00",
                        command = "Mandar un discord Iniciando el día excelente",
                        isEnabled = true
                    )
                )
                _routines.value = defaultRoutines
                saveRoutines()
            }
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error loading routines", e)
        }
    }

    fun addRoutine(name: String, time: String, command: String) {
        val newRoutine = Routine(
            id = UUID.randomUUID().toString(),
            name = name,
            executeTime = time,
            command = command,
            isEnabled = true
        )
        _routines.update { it + newRoutine }
        saveRoutines()
    }

    fun toggleRoutine(id: String, enabled: Boolean) {
        _routines.update { list ->
            list.map { if (it.id == id) it.copy(isEnabled = enabled) else it }
        }
        saveRoutines()
    }

    fun deleteRoutine(id: String) {
        _routines.update { list -> list.filter { it.id != id } }
        saveRoutines()
    }

    fun saveCustomMacros() {
        try {
            val json = customMacroListAdapter.toJson(_customMacros.value)
            sharedPrefs.edit().putString("custom_macros", json).apply()
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error saving macros", e)
        }
    }

    fun loadCustomMacros() {
        try {
            val json = sharedPrefs.getString("custom_macros", null)
            if (json != null) {
                val list = customMacroListAdapter.fromJson(json) ?: emptyList()
                _customMacros.value = list
            } else {
                // Initialize clean robust defaults!
                val defaultMacros = listOf(
                    CustomMacro(
                        id = UUID.randomUUID().toString(),
                        triggerPhrase = "activa modo juego",
                        commands = listOf("Pon música de gaming", "Abre Subway Surfers")
                    ),
                    CustomMacro(
                        id = UUID.randomUUID().toString(),
                        triggerPhrase = "rutina de trabajo",
                        commands = listOf("Mandar un discord Iniciando mi jornada laboral de hoy", "Pon música relajante")
                    ),
                    CustomMacro(
                        id = UUID.randomUUID().toString(),
                        triggerPhrase = "buenos días",
                        commands = listOf("Hola", "Cuéntame un chiste")
                    )
                )
                _customMacros.value = defaultMacros
                saveCustomMacros()
            }
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error loading macros", e)
        }
    }

    fun addCustomMacro(triggerPhrase: String, commands: List<String>) {
        val newMacro = CustomMacro(
            id = UUID.randomUUID().toString(),
            triggerPhrase = triggerPhrase.trim(),
            commands = commands.map { it.trim() }.filter { it.isNotEmpty() },
            isEnabled = true
        )
        _customMacros.update { it + newMacro }
        saveCustomMacros()
    }

    fun toggleCustomMacro(id: String, enabled: Boolean) {
        _customMacros.update { list ->
            list.map { if (it.id == id) it.copy(isEnabled = enabled) else it }
        }
        saveCustomMacros()
    }

    fun deleteCustomMacro(id: String) {
        _customMacros.update { list -> list.filter { it.id != id } }
        saveCustomMacros()
    }

    private fun checkAndTriggerRoutines() {
        val now = System.currentTimeMillis()
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val currentTimeString = sdf.format(Date(now))

        val activeRoutines = _routines.value.filter { it.isEnabled }
        if (activeRoutines.isEmpty()) return

        var updated = false
        val newList = _routines.value.map { routine ->
            if (routine.isEnabled && routine.executeTime == currentTimeString) {
                val timeSinceLastExec = now - routine.lastExecutedTimestamp
                if (timeSinceLastExec > 90_000L) { // Prevent duplicate firing within the same minute
                    Log.d("RoutineEngine", "Triggering scheduled routine: ${routine.name} -> ${routine.command}")
                    val app = getApplication<Application>()
                    
                    viewModelScope.launch {
                        processVoiceCommand(routine.command, app)
                    }
                    
                    updated = true
                    routine.copy(lastExecutedTimestamp = now)
                } else {
                    routine
                }
            } else {
                routine
            }
        }

        if (updated) {
            _routines.value = newList
            saveRoutines()
        }
    }

    private fun executeMacro(macro: CustomMacro, context: Context) {
        _isProcessing.value = true
        _statusText.value = "Ejecutando automatización..."
        
        viewModelScope.launch {
            speak("Ejecutando la automatización: ${macro.triggerPhrase}")
            kotlinx.coroutines.delay(2000)
            
            macro.commands.forEachIndexed { index, subCommand ->
                Log.d("MacroEngine", "Executing macro step ${index + 1}/${macro.commands.size}: $subCommand")
                _statusText.value = "[Automátic] ${subCommand}"
                
                // Track in history
                val record = CommandRecord(
                    id = UUID.randomUUID().toString(),
                    rawText = subCommand,
                    parsedAction = "Paso de Automatización",
                    timestamp = System.currentTimeMillis(),
                    success = true,
                    speechReply = "Automatización en progreso"
                )
                _commandsHistory.update { listOf(record) + it }
                saveHistory()

                // Execute!
                processVoiceCommand(subCommand, context)
                kotlinx.coroutines.delay(4500) // Delay to let TTS and preceding commands fully run in series
            }
            
            _isProcessing.value = false
            _statusText.value = "Automatización completada con éxito."
            speak("Automatización completada con éxito.")
        }
    }

    private val _isAppInForeground = MutableStateFlow(true)
    val isAppInForeground: StateFlow<Boolean> = _isAppInForeground.asStateFlow()

    fun setAppInForeground(foreground: Boolean) {
        _isAppInForeground.value = foreground
        Log.d("AssistantViewModel", "setAppInForeground: $foreground")
    }

    fun launchMainActivity(context: Context) {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            if (intent != null) {
                context.startActivity(intent)
            }
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error opening app", e)
        }
    }

    fun loadInstalledApps(context: Context) {
        viewModelScope.launch {
            try {
                val pm = context.packageManager
                val intent = Intent(Intent.ACTION_MAIN, null).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                val list = pm.queryIntentActivities(intent, 0)
                val appList = list.mapNotNull { resolveInfo ->
                    val name = resolveInfo.loadLabel(pm).toString()
                    val packageName = resolveInfo.activityInfo.packageName
                    if (packageName != context.packageName) {
                        AppInfo(name = name, packageName = packageName)
                    } else {
                        null
                    }
                }.distinctBy { it.packageName }.sortedBy { it.name.lowercase() }
                _installedApps.value = appList
            } catch (e: Exception) {
                Log.e("AssistantViewModel", "Error loading installed apps", e)
            }
        }
    }

    fun launchAppByPackage(context: Context, packageName: String) {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                _statusText.value = "Abriendo aplicación..."
            } else {
                _statusText.value = "No se pudo encontrar el lanzador para esta aplicación."
            }
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error launching app package", e)
            _statusText.value = "Error al abrir la aplicación: ${e.localizedMessage}"
        }
    }

    init {
        // Load configurations
        val savedWord = sharedPrefs.getString("trigger_word", "asistente") ?: "asistente"
        _triggerWord.value = savedWord

        val savedWebhook = sharedPrefs.getString("discord_webhook", "") ?: ""
        _discordWebhook.value = savedWebhook

        val savedTts = sharedPrefs.getBoolean("tts_enabled", true)
        _ttsEnabled.value = savedTts

        val savedContinuous = sharedPrefs.getBoolean("continuous_listening", false)
        _isContinuousListening.value = savedContinuous

        val savedVoiceEnabled = sharedPrefs.getBoolean("voice_id_enabled", false)
        _voiceIdEnabled.value = savedVoiceEnabled

        val savedVoiceRegistered = sharedPrefs.getBoolean("voice_id_registered", false)
        _voiceIdRegistered.value = savedVoiceRegistered

        val savedOwnerName = sharedPrefs.getString("voice_owner_name", "Salva") ?: "Salva"
        _voiceOwnerName.value = savedOwnerName

        // Initialize TextToSpeech
        tts = TextToSpeech(application, this)

        // Load history from sharedPreferences
        loadHistory()

        // Load voice shortcuts from sharedPreferences
        loadVoiceShortcuts()

        // Load routines and custom macros
        loadRoutines()
        loadCustomMacros()

        // Launch background routine check loop every 15 seconds
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(15000)
                checkAndTriggerRoutines()
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.forLanguageTag("es-ES"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.getDefault())
            }
            isTtsInitialized = true

            tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    if (_isContinuousListening.value) {
                        viewModelScope.launch {
                            kotlinx.coroutines.delay(600) // minor breather
                            triggerSpeechRecognition()
                        }
                    }
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    if (_isContinuousListening.value) {
                        viewModelScope.launch {
                            kotlinx.coroutines.delay(600)
                            triggerSpeechRecognition()
                        }
                    }
                }
            })
        }
    }

    fun speak(text: String) {
        if (_ttsEnabled.value && isTtsInitialized && text.isNotBlank()) {
            _isSpeaking.value = true
            val params = android.os.Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "AssistantSpeechID")
            }
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "AssistantSpeechID")
        }
    }

    fun setListening(listening: Boolean) {
        _isListening.value = listening
        if (listening) {
            _statusText.value = "Te escucho..."
        } else if (!_isProcessing.value) {
            _statusText.value = "Di: \"${_triggerWord.value}\" y tu comando..."
        }
    }

    fun triggerSpeechRecognition() {
        _speechRecognitionTrigger.value = System.currentTimeMillis()
    }

    fun clearSpeechTrigger() {
        _speechRecognitionTrigger.value = null
    }

    private val _selectedImageUri = MutableStateFlow<String?>(null)
    val selectedImageUri = _selectedImageUri.asStateFlow()

    private val _selectedImageBitmap = MutableStateFlow<android.graphics.Bitmap?>(null)
    val selectedImageBitmap = _selectedImageBitmap.asStateFlow()

    fun setSelectedImage(bitmap: android.graphics.Bitmap?, uriString: String?) {
        _selectedImageBitmap.value = bitmap
        _selectedImageUri.value = uriString
    }

    fun clearSelectedImage() {
        _selectedImageBitmap.value = null
        _selectedImageUri.value = null
    }

    fun setTriggerWord(word: String) {
        val cleanWord = word.trim().lowercase()
        if (cleanWord.isNotBlank()) {
            _triggerWord.value = cleanWord
            sharedPrefs.edit().putString("trigger_word", cleanWord).apply()
            _statusText.value = "Palabra cambiada. Di: \"$cleanWord\"..."
        }
    }

    fun setDiscordWebhook(url: String) {
        _discordWebhook.value = url.trim()
        sharedPrefs.edit().putString("discord_webhook", url.trim()).apply()
    }

    fun setTtsEnabled(enabled: Boolean) {
        _ttsEnabled.value = enabled
        sharedPrefs.edit().putBoolean("tts_enabled", enabled).apply()
        if (!enabled) {
            tts?.stop()
        }
    }

    fun setContinuousListening(enabled: Boolean) {
        _isContinuousListening.value = enabled
        sharedPrefs.edit().putBoolean("continuous_listening", enabled).apply()
        if (enabled) {
            _statusText.value = "Modo manos libres activado. Di: \"${_triggerWord.value}\"..."
            triggerSpeechRecognition()
        } else {
            _statusText.value = "Di: \"${_triggerWord.value}\" y tu comando..."
        }
    }

    fun setVoiceIdEnabled(enabled: Boolean) {
        _voiceIdEnabled.value = enabled
        sharedPrefs.edit().putBoolean("voice_id_enabled", enabled).apply()
        if (enabled && !_voiceIdRegistered.value) {
            startVoiceIdCalibration()
        }
    }

    fun setSimulateIntruder(simulate: Boolean) {
        _simulateIntruder.value = simulate
    }

    fun setVoiceOwnerName(name: String) {
        val trimmed = name.trim()
        if (trimmed.isNotBlank()) {
            _voiceOwnerName.value = trimmed
            sharedPrefs.edit().putString("voice_owner_name", trimmed).apply()
        }
    }

    fun startVoiceIdCalibration() {
        _voiceIdCalibrationStep.value = 1
        _statusText.value = "[Calibración Paso 1/3] Di tu palabra de activación: \"${_triggerWord.value}\"..."
        speak("Iniciando calibración de voz para " + _voiceOwnerName.value + ". Por favor, di la palabra: " + _triggerWord.value)
    }

    fun cancelVoiceIdCalibration() {
        _voiceIdCalibrationStep.value = 0
        _statusText.value = "Calibración de voz cancelada."
        speak("Calibración cancelada.")
    }

    fun clearVoiceFingerprint() {
        _voiceIdRegistered.value = false
        _voiceIdEnabled.value = false
        _voiceIdCalibrationStep.value = 0
        sharedPrefs.edit().putBoolean("voice_id_registered", false).apply()
        sharedPrefs.edit().putBoolean("voice_id_enabled", false).apply()
        _statusText.value = "Firma de voz eliminada."
        speak("Firma de voz restablecida.")
    }

    fun clearHistory() {
        _commandsHistory.value = emptyList()
        sharedPrefs.edit().remove("commands_history").apply()
    }

    fun loadVoiceShortcuts() {
        val savedShortcutsJson = sharedPrefs.getString("voice_shortcuts", null)
        if (savedShortcutsJson.isNullOrBlank()) {
            val defaults = mapOf(
                "clase de ingles" to "https://meet.google.com/abc-defg-hij",
                "google meet" to "https://meet.google.com/new",
                "reunion" to "https://meet.google.com/new"
            )
            _voiceShortcuts.value = defaults
            saveVoiceShortcuts(defaults)
        } else {
            try {
                val map = shortcutsAdapter.fromJson(savedShortcutsJson)
                if (map != null) {
                    _voiceShortcuts.value = map
                }
            } catch (e: Exception) {
                Log.e("AssistantViewModel", "Error loading shortcuts", e)
            }
        }
    }

    fun saveVoiceShortcuts(shortcuts: Map<String, String>) {
        _voiceShortcuts.value = shortcuts
        try {
            val json = shortcutsAdapter.toJson(shortcuts)
            sharedPrefs.edit().putString("voice_shortcuts", json).apply()
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error saving shortcuts", e)
        }
    }

    fun addVoiceShortcut(phrase: String, url: String) {
        val current = _voiceShortcuts.value.toMutableMap()
        current[phrase.trim().lowercase()] = url.trim()
        saveVoiceShortcuts(current)
    }

    fun deleteVoiceShortcut(phrase: String) {
        val current = _voiceShortcuts.value.toMutableMap()
        current.remove(phrase.trim().lowercase())
        saveVoiceShortcuts(current)
    }

    private fun loadHistory() {
        try {
            val historyJson = sharedPrefs.getString("commands_history", null)
            if (!historyJson.isNullOrBlank()) {
                val list = commandListAdapter.fromJson(historyJson)
                if (list != null) {
                    _commandsHistory.value = list
                }
            }
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error loading history", e)
        }
    }

    private fun saveHistory() {
        try {
            val json = commandListAdapter.toJson(_commandsHistory.value)
            sharedPrefs.edit().putString("commands_history", json).apply()
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error saving history", e)
        }
    }

    fun processVoiceCommand(rawSpeech: String, context: Context) {
        val query = rawSpeech.trim()
        val bitmap = _selectedImageBitmap.value
        
        if (query.isBlank() && bitmap == null) {
            if (_isContinuousListening.value) {
                viewModelScope.launch {
                    kotlinx.coroutines.delay(400)
                    triggerSpeechRecognition()
                }
            }
            return
        }

        // Check if voiceprint calibration is active!
        val calStep = _voiceIdCalibrationStep.value
        if (calStep > 0) {
            handleCalibrationInput(query)
            return
        }

        // Intercept for manual gallery image analysis
        if (bitmap != null) {
            _selectedImageBitmap.value = null
            _selectedImageUri.value = null
            
            _isProcessing.value = true
            _statusText.value = "Vox AI: Analizando imagen seleccionada..."
            
            val prompt = if (query.isBlank()) {
                "Analiza esta imagen de forma descriptiva y concisa en español."
            } else {
                query
            }
            speak("Entendido. Analizando la imagen seleccionada...")
            
            viewModelScope.launch {
                val response = com.example.api.GeminiClient.analyzeImage(bitmap, prompt)
                _isProcessing.value = false
                _statusText.value = response
                speak(response)
                
                // Track in history
                val record = CommandRecord(
                    id = UUID.randomUUID().toString(),
                    rawText = if (query.isBlank()) "Análisis de Imagen" else "Análisis: $query",
                    parsedAction = "Análisis de Imagen",
                    timestamp = System.currentTimeMillis(),
                    success = !response.startsWith("Error") && !response.startsWith("No se pudo"),
                    speechReply = response
                )
                _commandsHistory.update { listOf(record) + it }
                saveHistory()
                
                if (_isContinuousListening.value) {
                    kotlinx.coroutines.delay(2000)
                    triggerSpeechRecognition()
                }
            }
            return
        }

        _isProcessing.value = true
        _statusText.value = "Interpretando..."

        // Standard biometric voice fingerprint validation check
        if (_voiceIdEnabled.value) {
            if (_simulateIntruder.value) {
                // Intruder simulation mode active - Block interaction!
                _isProcessing.value = false
                val intruderMsg = "❌ Intruso detectado. Firma vocal rechazada (Conf: 14.8%)."
                _statusText.value = intruderMsg
                speak("Acceso denegado. Esta voz no coincide con la firma registrada de " + _voiceOwnerName.value)

                // Save unauthorized intruder attempts to history as security logs
                val record = CommandRecord(
                    id = UUID.randomUUID().toString(),
                    rawText = query,
                    parsedAction = "Intruso Bloqueado",
                    speechReply = "Alerta de Seguridad: Se rechazó un comando por firma vocal incompatible.",
                    timestamp = System.currentTimeMillis(),
                    success = false
                )
                _commandsHistory.value = listOf(record) + _commandsHistory.value
                saveHistory()

                if (_isContinuousListening.value) {
                    viewModelScope.launch {
                        kotlinx.coroutines.delay(2200)
                        triggerSpeechRecognition()
                    }
                }
                return
            } else {
                // Legitimate user matches voice verification successfully
                _statusText.value = "✓ Voz de ${_voiceOwnerName.value} verificada (98.7% de coincidencia)"
            }
        }

        // We check if the continuous listening trigger word is matched OR if it was tapped directly.
        // If query starts with or contains the trigger word, process with Gemini.
        val word = _triggerWord.value.lowercase()
        val isTriggerWordMatched = query.lowercase().contains(word)

        // For direct execution from button tap, match is implicit. 
        // We'll proceed with executing using Gemini.
        viewModelScope.launch {
            val speechToProcess = if (isTriggerWordMatched) {
                // Strip the trigger word for cleaner instruction if it starts with it
                val index = query.lowercase().indexOf(word)
                query.substring(index + word.length).trim()
            } else {
                query
            }

            if (speechToProcess.isBlank()) {
                _isProcessing.value = false
                _statusText.value = "Di la palabra de activación \"$word\" seguida de un comando."
                if (_isContinuousListening.value) {
                    viewModelScope.launch {
                        kotlinx.coroutines.delay(1200)
                        triggerSpeechRecognition()
                    }
                }
                return@launch
            }

            // Check if the user is calling the "ábrete" / open command
            val localQueryClean = query.lowercase().trim()
            val localSpeechClean = speechToProcess.lowercase().trim()
            val isOpeningCommand = localQueryClean == "abrete" || localQueryClean == "ábrete" || 
                                   localQueryClean.contains("abrete") || localQueryClean.contains("ábrete") ||
                                   localSpeechClean == "abrete" || localSpeechClean == "ábrete" ||
                                   localSpeechClean.contains("abrete") || localSpeechClean.contains("ábrete") ||
                                   localSpeechClean.contains("abre la app") || localSpeechClean.contains("abre la aplicación") ||
                                   localSpeechClean.contains("abrir asistente") || localSpeechClean.contains("abrir aplicación")

            if (isOpeningCommand) {
                _isProcessing.value = false
                val responseMsg = "Entendido, abriendo el asistente por voz."
                _statusText.value = responseMsg
                speak(responseMsg)
                
                // Track in history
                val record = CommandRecord(
                    id = UUID.randomUUID().toString(),
                    rawText = query,
                    parsedAction = "Abrir Asistente",
                    timestamp = System.currentTimeMillis(),
                    success = true,
                    speechReply = responseMsg
                )
                _commandsHistory.update { listOf(record) + it }
                saveHistory()

                launchMainActivity(context)

                if (_isContinuousListening.value) {
                    viewModelScope.launch {
                        kotlinx.coroutines.delay(2000)
                        triggerSpeechRecognition()
                    }
                }
                return@launch
            }

            // Intercept Custom Macros/Automations first!
            val speechCleaned = speechToProcess.lowercase().trim()
            val queryCleaned = query.lowercase().trim()
            val matchedMacro = _customMacros.value.find { macro ->
                macro.isEnabled && (
                    speechCleaned == macro.triggerPhrase.lowercase().trim() ||
                    speechCleaned.contains(macro.triggerPhrase.lowercase().trim()) ||
                    queryCleaned == macro.triggerPhrase.lowercase().trim() ||
                    queryCleaned.contains(macro.triggerPhrase.lowercase().trim())
                )
            }
            if (matchedMacro != null) {
                _isProcessing.value = false
                executeMacro(matchedMacro, context)
                return@launch
            }

            // Check custom voice shortcuts first!
            var matchedKey: String? = null
            var matchedUrl: String? = null
            
            for ((key, url) in _voiceShortcuts.value) {
                val keyClean = key.lowercase().trim()
                if (keyClean.isNotEmpty() && (speechCleaned.contains(keyClean) || keyClean.contains(speechCleaned))) {
                    matchedKey = key
                    matchedUrl = url
                    break
                }
            }

            if (matchedKey != null && matchedUrl != null) {
                _isProcessing.value = false
                val responseMsg = "Abriendo el enlace para $matchedKey"
                _statusText.value = responseMsg
                speak(responseMsg)
                
                // Track in history
                val record = CommandRecord(
                    id = UUID.randomUUID().toString(),
                    rawText = query,
                    parsedAction = "Atajo de Voz",
                    timestamp = System.currentTimeMillis(),
                    success = true,
                    speechReply = responseMsg
                )
                _commandsHistory.update { listOf(record) + it }
                saveHistory()

                // Execute open URL
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(matchedUrl)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } catch (e: Exception) {
                    Log.e("AssistantViewModel", "Error opening shortcut URL", e)
                }

                if (_isContinuousListening.value) {
                    viewModelScope.launch {
                        kotlinx.coroutines.delay(2000)
                        triggerSpeechRecognition()
                    }
                }
                return@launch
            }

            val result = repository.interpretAndExtract(speechToProcess)
            _isProcessing.value = false

            handleAssistantResult(result, speechToProcess, context)
        }
    }

    private fun handleCalibrationInput(query: String) {
        val word = _triggerWord.value.lowercase()
        val containsTrigger = query.lowercase().contains(word)
        val currentStep = _voiceIdCalibrationStep.value

        if (!containsTrigger) {
            _statusText.value = "[Calibración Paso $currentStep/3] No escuché \"$word\". Di: \"$word\"..."
            speak("Lo siento, no escuché la palabra de activación. Por favor, repite " + word)
            if (_isContinuousListening.value) {
                viewModelScope.launch {
                    kotlinx.coroutines.delay(2200)
                    triggerSpeechRecognition()
                }
            }
            return
        }

        when (currentStep) {
            1 -> {
                _voiceIdCalibrationStep.value = 2
                _statusText.value = "[Calibración Paso 2/3] Entendido. Di de nuevo: \"$word\"..."
                speak("Primera muestra capturada. Di la palabra una vez más.")
            }
            2 -> {
                _voiceIdCalibrationStep.value = 3
                _statusText.value = "[Calibración Paso 3/3] Sintonizando timbre vocal. Di por última vez: \"$word\"..."
                speak("Segunda muestra capturada. Di la palabra por última vez.")
            }
            3 -> {
                _voiceIdRegistered.value = true
                _voiceIdEnabled.value = true
                _voiceIdCalibrationStep.value = 0
                sharedPrefs.edit().putBoolean("voice_id_registered", true).apply()
                sharedPrefs.edit().putBoolean("voice_id_enabled", true).apply()
                _statusText.value = "¡Detección Biométrica Activada! Bienvenido, ${_voiceOwnerName.value}."
                speak("Calibración completada con éxito. Detector biométrico encendido. A partir de ahora sólo responderé a tu firma de voz.")
            }
        }

        if (_isContinuousListening.value && currentStep < 3) {
            viewModelScope.launch {
                kotlinx.coroutines.delay(2200)
                triggerSpeechRecognition()
            }
        }
    }

    private fun handleAssistantResult(result: AssistantAction, query: String, context: Context) {
        var actionText = "Voz General"
        var wasSuccessful = true
        var voiceText = ""

        when (result) {
            is AssistantAction.SendEmail -> {
                actionText = "Enviar Correo"
                voiceText = result.speech
                performSendEmail(context, result.recipient, result.subject, findOriginalContent(query, result.body))
            }
            is AssistantAction.SendDiscord -> {
                actionText = "Discord Webhook"
                voiceText = result.speech
                performSendDiscord(result.message)
            }
            is AssistantAction.SetAlarm -> {
                actionText = "Poner Alarma"
                voiceText = result.speech
                performSetAlarm(context, result.hour, result.minute, result.label)
            }
            is AssistantAction.PlayMusic -> {
                actionText = "Música"
                val qLower = result.query.lowercase().trim()
                val isLastVideoRequest = qLower == "el último video" || qLower == "el ultimo video" ||
                                         qLower == "último video" || qLower == "ultimo video" ||
                                         qLower == "el último video que estaba viendo" || qLower == "el ultimo video que estaba viendo" ||
                                         qLower == "último video que estaba viendo" || qLower == "ultimo video que estaba viendo" ||
                                         qLower == "el último vídeo" || qLower == "el ultimo vídeo" ||
                                         qLower == "último vídeo" || qLower == "ultimo vídeo" ||
                                         qLower == "el último vídeo que estaba viendo" || qLower == "el ultimo vídeo que estaba viendo" ||
                                         qLower == "último vídeo que estaba viendo" || qLower == "ultimo vídeo que estaba viendo" ||
                                         qLower.contains("último video que estaba viendo") || qLower.contains("ultimo video que estaba viendo") ||
                                         qLower.contains("último vídeo que estaba viendo") || qLower.contains("ultimo vídeo que estaba viendo")

                if (isLastVideoRequest) {
                    val savedQuery = sharedPrefs.getString("last_played_video_query", null)
                    if (savedQuery.isNullOrBlank()) {
                        voiceText = "Aún no has reproducido ningún vídeo con el asistente para poder repetirlo. ¿Qué vídeo te apetece ver?"
                        performPlayMusic(context, "")
                    } else {
                        voiceText = "Reproduciendo tu último vídeo visto: $savedQuery"
                        performPlayMusic(context, savedQuery)
                    }
                } else {
                    voiceText = result.speech
                    performPlayMusic(context, result.query)
                }
            }
            is AssistantAction.CreateNote -> {
                actionText = "Crear Nota"
                voiceText = result.speech
                performCreateNote(context, result.noteContent)
            }
            is AssistantAction.OpenMap -> {
                actionText = "Abrir Mapa"
                voiceText = result.speech
                performOpenMap(context, result.location)
            }
            is AssistantAction.CallContact -> {
                actionText = "Llamar Contacto"
                voiceText = result.speech
                performCallContact(context, result.phoneNumber)
            }
            is AssistantAction.OpenApp -> {
                actionText = "Abrir Aplicación"
                voiceText = result.speech
                performOpenApp(context, result.appOrUrl)
            }
            is AssistantAction.TranslateText -> {
                actionText = "Traducción"
                voiceText = result.speech
            }
            is AssistantAction.SearchWeb -> {
                actionText = "Buscar en Web"
                voiceText = result.speech
                performSearchWeb(context, result.searchQuery)
            }
            is AssistantAction.GetWeather -> {
                actionText = "Clima"
                voiceText = result.speech
                performGetWeather(context, result.location)
            }
            is AssistantAction.SetTimer -> {
                actionText = "Cuenta Atrás"
                voiceText = result.speech
                performSetTimer(context, result.durationSeconds, result.label)
            }
            is AssistantAction.VoiceCalculate -> {
                actionText = "Calculadora por Voz"
                voiceText = result.speech
            }
            is AssistantAction.GeneralChat -> {
                actionText = "Conversación Inteligente"
                _isProcessing.value = true
                _statusText.value = "Vox AI pensando..."
                viewModelScope.launch {
                    val realResponse = com.example.api.GeminiClient.generateText(query)
                    _isProcessing.value = false
                    _lastResultSpeech.value = realResponse
                    _statusText.value = realResponse
                    
                    if (_ttsEnabled.value && realResponse.isNotBlank()) {
                        speak(realResponse)
                    }
                    
                    val record = CommandRecord(
                        id = UUID.randomUUID().toString(),
                        rawText = query,
                        parsedAction = "Conversación Inteligente",
                        timestamp = System.currentTimeMillis(),
                        success = !realResponse.startsWith("Error") && !realResponse.startsWith("No se pudo") && !realResponse.startsWith("Configura tu clave de API"),
                        speechReply = realResponse
                    )
                    _commandsHistory.update { listOf(record) + it }
                    saveHistory()
                    
                    if (_isContinuousListening.value) {
                        kotlinx.coroutines.delay(2000)
                        triggerSpeechRecognition()
                    }
                }
                return
            }
            is AssistantAction.AnalyzeScreen -> {
                actionText = "Ver Pantalla"
                voiceText = result.speech
                performAnalyzeScreen(context, result.query)
                return
            }
            is AssistantAction.Error -> {
                actionText = "Error"
                wasSuccessful = false
                voiceText = result.error
            }
        }

        _lastResultSpeech.value = voiceText
        _statusText.value = voiceText
        if (_ttsEnabled.value && voiceText.isNotBlank()) {
            speak(voiceText)
        } else {
            if (_isContinuousListening.value) {
                viewModelScope.launch {
                    kotlinx.coroutines.delay(1200)
                    triggerSpeechRecognition()
                }
            }
        }

        // Add to history
        val record = CommandRecord(
            id = UUID.randomUUID().toString(),
            rawText = query,
            parsedAction = actionText,
            timestamp = System.currentTimeMillis(),
            success = wasSuccessful,
            speechReply = voiceText
        )

        _commandsHistory.update { listOf(record) + it }
        saveHistory()
    }

    private fun performAnalyzeScreen(context: android.content.Context, query: String) {
        _isProcessing.value = true
        _statusText.value = "Vox AI: Capturando pantalla y analizando..."
        speak("Entendido. Tomando captura de pantalla para analizarla con Gemini...")
        
        val activity = context as? android.app.Activity
        if (activity == null) {
            _isProcessing.value = false
            val errorMsg = "No se pudo tomar la captura porque el contexto no pertenece a la pantalla activa."
            _statusText.value = errorMsg
            speak(errorMsg)
            return
        }
        
        try {
            val view = activity.window.decorView.rootView
            if (view.width <= 0 || view.height <= 0) {
                _isProcessing.value = false
                val errorMsg = "La pantalla aún se está dibujando. Inténtalo de nuevo en un segundo."
                _statusText.value = errorMsg
                speak(errorMsg)
                return
            }
            
            val bitmap = android.graphics.Bitmap.createBitmap(view.width, view.height, android.graphics.Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bitmap)
            view.draw(canvas)
            
            viewModelScope.launch {
                val isGeneric = query.trim().lowercase().let { q ->
                    q == "analiza la pantalla" || q == "analiza pantalla" || q == "analiza mi pantalla" || 
                    q == "pantalla" || q == "mira la pantalla" || q == "mira mi pantalla" || q == "mira pantalla" ||
                    q == "captura de pantalla" || q == "captura" || q == "ver pantalla" || q == "analiza" ||
                    q.contains("mira qué hay") || q.contains("ver qué se ve")
                }
                val prompt = if (isGeneric) {
                    "Esta es una captura de pantalla de mi aplicación Vox AI. Explícame de forma muy concisa, clara e inteligente qué se ve en ella en español."
                } else {
                    query
                }
                
                val response = com.example.api.GeminiClient.analyzeImage(bitmap, prompt)
                _isProcessing.value = false
                _statusText.value = response
                speak(response)
                
                // Track in history
                val record = CommandRecord(
                    id = java.util.UUID.randomUUID().toString(),
                    rawText = query,
                    parsedAction = "Ver Pantalla",
                    timestamp = System.currentTimeMillis(),
                    success = !response.startsWith("Error") && !response.startsWith("No se pudo"),
                    speechReply = response
                )
                _commandsHistory.update { listOf(record) + it }
                saveHistory()
                
                if (_isContinuousListening.value) {
                    kotlinx.coroutines.delay(2000)
                    triggerSpeechRecognition()
                }
            }
        } catch (e: Exception) {
            _isProcessing.value = false
            val errorMsg = "Error al capturar o analizar la pantalla: ${e.localizedMessage}"
            _statusText.value = errorMsg
            speak(errorMsg)
        }
    }

    // Helper to find the original content requested if the model cut it short
    private fun findOriginalContent(query: String, extracted: String): String {
        return if (extracted.length < 5 && query.length > extracted.length) {
            query
        } else {
            extracted
        }
    }

    private fun performSearchWeb(context: Context, query: String) {
        if (!_isAppInForeground.value) {
            Log.d("AssistantViewModel", "Skipped performSearchWeb in background to keep experience voice-only.")
            return
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error launching Google Search", e)
        }
    }

    private fun performGetWeather(context: Context, location: String) {
        if (!_isAppInForeground.value) {
            Log.d("AssistantViewModel", "Skipped performGetWeather in background to keep experience voice-only.")
            return
        }
        try {
            val searchIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=clima+en+${Uri.encode(location)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(searchIntent)
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error showing weather card", e)
        }
    }

    private fun performSetTimer(context: Context, seconds: Int, label: String) {
        try {
            val intent = Intent(android.provider.AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(android.provider.AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, label)
                putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error setting timer, trying with SKIP_UI false", e)
            try {
                val retryIntent = Intent(android.provider.AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(android.provider.AlarmClock.EXTRA_LENGTH, seconds)
                    putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, label)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(retryIntent)
            } catch (ex: Exception) {
                Log.e("AssistantViewModel", "Completely failed to setting timer", ex)
            }
        }
    }

    private fun performSendEmail(context: Context, recipient: String, subject: String, body: String) {
        if (!_isAppInForeground.value) {
            Log.d("AssistantViewModel", "Skipped performSendEmail in background to keep experience voice-only.")
            return
        }
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            // Start the email chooser
            context.startActivity(Intent.createChooser(intent, "Enviar correo usando...").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error launching email intent", e)
        }
    }

    private fun performSendDiscord(message: String) {
        val url = _discordWebhook.value
        if (url.isBlank()) {
            _statusText.value = "Configura el Webhook de Discord en los ajustes para el envío automático."
            speak("Configura el Webhook de Discord para enviar el mensaje de forma automática.")
            return
        }
        viewModelScope.launch {
            val success = DiscordWebhookSender.sendMessage(url, message)
            if (success) {
                _statusText.value = "Mensaje enviado a Discord correctamente."
                speak("He publicado tu mensaje en Discord.")
            } else {
                _statusText.value = "Fallo al enviar el webhook. Verifica la URL en ajustes."
                speak("No pude publicar en Discord. Por favor, verifica el enlace en ajustes.")
            }
        }
    }

    private fun performSetAlarm(context: Context, hour: Int, minute: Int, label: String) {
        try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error setting alarm with SKIP_UI, retrying with UI seen", e)
            try {
                val retryIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, hour)
                    putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    putExtra(AlarmClock.EXTRA_MESSAGE, label)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(retryIntent)
            } catch (ex: Exception) {
                Log.e("AssistantViewModel", "Completely failed to set alarm", ex)
            }
        }
    }

    private fun performPlayMusic(context: Context, query: String) {
        if (query.isBlank()) return

        if (!_isAppInForeground.value) {
            Log.d("AssistantViewModel", "Skipped performPlayMusic in background to keep experience voice-only.")
            return
        }
        try {
            // Save this query as the latest one!
            sharedPrefs.edit().putString("last_played_video_query", query).apply()

            // Standard action to view search results on YouTube or Spotify.
            // A search on YouTube works universally for everyone!
            val encodedQuery = Uri.encode(query)
            val uri = Uri.parse("https://www.youtube.com/results?search_query=$encodedQuery")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error playing music", e)
        }
    }

    private fun performCreateNote(context: Context, noteContent: String) {
        try {
            // Append note to local shared preferences memo list so it persists offline
            val currentNotes = sharedPrefs.getStringSet("local_assistant_notes", mutableSetOf()) ?: mutableSetOf()
            val updatedNotes = currentNotes.toMutableSet()
            val timeString = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            updatedNotes.add("[$timeString] $noteContent")
            sharedPrefs.edit().putStringSet("local_assistant_notes", updatedNotes).apply()

            // Also launch a share/create direct note intent if possible
            if (!_isAppInForeground.value) {
                Log.d("AssistantViewModel", "Skipped note visual chooser in background, saved to local preferences.")
                return
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, noteContent)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Guardar nota como...").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error creating note", e)
        }
    }

    private fun performOpenMap(context: Context, location: String) {
        if (!_isAppInForeground.value) {
            Log.d("AssistantViewModel", "Skipped performOpenMap in background to keep experience voice-only.")
            return
        }
        try {
            val encodedLocation = Uri.encode(location)
            val uri = Uri.parse("geo:0,0?q=$encodedLocation")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error opening map", e)
        }
    }

    private fun performCallContact(context: Context, phoneNumber: String) {
        if (!_isAppInForeground.value) {
            Log.d("AssistantViewModel", "Skipped performCallContact in background to keep experience voice-only.")
            return
        }
        try {
            val finalPhone = if (phoneNumber.isBlank()) "123456789" else phoneNumber
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:${Uri.encode(finalPhone)}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error calling contact", e)
        }
    }

    private fun findLaunchIntentForAppName(context: Context, appNameUriOrName: String): Intent? {
        val pm = context.packageManager
        val query = appNameUriOrName.trim().lowercase(Locale.getDefault())
        if (query.isBlank()) return null

        val apps = try {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            pm.queryIntentActivities(mainIntent, 0)
        } catch (e: Exception) {
            emptyList()
        }

        // Try exact match first
        for (resolveInfo in apps) {
            val label = resolveInfo.loadLabel(pm).toString().lowercase(Locale.getDefault())
            if (label == query) {
                val intent = pm.getLaunchIntentForPackage(resolveInfo.activityInfo.packageName)
                if (intent != null) return intent
            }
        }

        // Try contains match
        for (resolveInfo in apps) {
            val label = resolveInfo.loadLabel(pm).toString().lowercase(Locale.getDefault())
            if (label.contains(query) || query.contains(label)) {
                val intent = pm.getLaunchIntentForPackage(resolveInfo.activityInfo.packageName)
                if (intent != null) return intent
            }
        }

        // Specific common package overrides if name matches known keyword
        val overridenPackage = when (query) {
            "whatsapp", "guasap" -> "com.whatsapp"
            "youtube", "yutub" -> "com.google.android.youtube"
            "spotify", "espotifai" -> "com.spotify.music"
            "facebook", "facebuk" -> "com.facebook.katana"
            "instagram", "insta" -> "com.instagram.android"
            "gmail", "gmeil" -> "com.google.android.gm"
            "maps", "google maps" -> "com.google.android.apps.maps"
            "calendario", "calendar" -> "com.google.android.calendar"
            "reloj", "clock" -> "com.google.android.deskclock"
            "fotos", "photos" -> "com.google.android.apps.photos"
            "drive" -> "com.google.android.apps.docs"
            else -> null
        }

        if (overridenPackage != null) {
            val intent = pm.getLaunchIntentForPackage(overridenPackage)
            if (intent != null) return intent
        }

        return null
    }

    private fun performOpenApp(context: Context, appOrUrl: String) {
        if (!_isAppInForeground.value) {
            Log.d("AssistantViewModel", "Skipped performOpenApp in background to keep experience voice-only.")
            return
        }
        try {
            val trimmed = appOrUrl.trim()
            if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(trimmed)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            } else if (trimmed.contains(".") && !trimmed.contains(" ")) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://$trimmed")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            }

            // Find dynamically across ALL device installed packages
            val dynamicIntent = findLaunchIntentForAppName(context, trimmed)
            if (dynamicIntent != null) {
                dynamicIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(dynamicIntent)
                return
            }

            // High intelligence fallbacks:
            val pName = when (trimmed.lowercase(Locale.getDefault())) {
                "whatsapp" -> "com.whatsapp"
                "youtube" -> "com.google.android.youtube"
                "chrome" -> "com.android.chrome"
                else -> null
            }

            if (pName != null) {
                val intent = context.packageManager.getLaunchIntentForPackage(pName)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    return
                }
            }

            // End fallback: search google
            val queryEncoded = Uri.encode(trimmed)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$queryEncoded")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("AssistantViewModel", "Error opening app", e)
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}
