package com.example.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Routine(
    val id: String,
    val name: String,
    val executeTime: String, // e.g., "15:00" or "08:30"
    val command: String,
    val isEnabled: Boolean = true,
    val lastExecutedTimestamp: Long = 0L
)
