package com.example.api

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object DiscordWebhookSender {
    suspend fun sendMessage(webhookUrl: String, content: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = URL(webhookUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.doOutput = true

            // Simple json body builder
            val jsonPayload = "{\"content\": ${escapeJsonString(content)}}"

            val writer = OutputStreamWriter(connection.outputStream)
            writer.write(jsonPayload)
            writer.flush()
            writer.close()

            val responseCode = connection.responseCode
            connection.disconnect()
            responseCode in 200..299
        } catch (e: Exception) {
            Log.e("DiscordWebhookSender", "Error sending Discord webhook message", e)
            false
        }
    }

    private fun escapeJsonString(input: String): String {
        val builder = java.lang.StringBuilder()
        builder.append("\"")
        for (c in input) {
            when (c) {
                '\"' -> builder.append("\\\"")
                '\\' -> builder.append("\\\\")
                '\n' -> builder.append("\\n")
                '\r' -> builder.append("\\r")
                '\t' -> builder.append("\\t")
                else -> {
                    if (c.code < 32 || c.code > 126) {
                        builder.append(String.format("\\u%04x", c.code))
                    } else {
                        builder.append(c)
                    }
                }
            }
        }
        builder.append("\"")
        return builder.toString()
    }
}
