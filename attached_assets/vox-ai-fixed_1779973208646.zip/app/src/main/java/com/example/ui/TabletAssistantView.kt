package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppInfo
import com.example.model.CommandRecord
import com.example.HistoryCard
import com.example.borderStroke

@Composable
fun TabletAssistantView(
    modifier: Modifier = Modifier,
    isListening: Boolean,
    isContinuousListening: Boolean,
    onToggleContinuous: (Boolean) -> Unit,
    isProcessing: Boolean,
    triggerWord: String,
    discordWebhook: String,
    ttsEnabled: Boolean,
    statusText: String,
    commandsHistory: List<CommandRecord>,
    rmsValue: Float,
    onTriggerMic: () -> Unit,
    onSendTextCommand: (String) -> Unit,
    onUpdateTriggerWord: (String) -> Unit,
    onUpdateDiscordWebhook: (String) -> Unit,
    onToggleTts: (Boolean) -> Unit,
    onClearHistory: () -> Unit,
    installedApps: List<AppInfo>,
    onLaunchApp: (String) -> Unit,
    voiceIdEnabled: Boolean,
    voiceIdRegistered: Boolean,
    voiceIdCalibrationStep: Int,
    voiceOwnerName: String,
    simulateIntruder: Boolean,
    onToggleVoiceId: (Boolean) -> Unit,
    onToggleSimulateIntruder: (Boolean) -> Unit,
    onUpdateVoiceOwnerName: (String) -> Unit,
    onStartVoiceCalibration: () -> Unit,
    onCancelVoiceCalibration: () -> Unit,
    onClearVoiceFingerprint: () -> Unit,
    onTriggerSettings: () -> Unit,
    routines: List<com.example.model.Routine> = emptyList(),
    onAddRoutine: (String, String, String) -> Unit = { _, _, _ -> },
    onToggleRoutine: (String, Boolean) -> Unit = { _, _ -> },
    onDeleteRoutine: (String) -> Unit = {},
    customMacros: List<com.example.model.CustomMacro> = emptyList(),
    onAddCustomMacro: (String, List<String>) -> Unit = { _, _ -> },
    onToggleCustomMacro: (String, Boolean) -> Unit = { _, _ -> },
    onDeleteCustomMacro: (String) -> Unit = {}
) {
    var textCommandInput by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    // Infinite animation transition for pulsing visual ring effect on Tablet
    val infiniteTransition = rememberInfiniteTransition(label = "TabletRadar")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "alpha"
    )

    var selectedTab by remember { mutableStateOf(0) } // 0: INICIO, 1: HISTORIAL

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F1115))
            .drawWithContent {
                // Large radial gradient backing glow for wide displays
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF3B82F6).copy(alpha = 0.14f), Color.Transparent),
                        radius = size.width * 0.45f,
                        center = androidx.compose.ui.geometry.Offset(size.width * 0.25f, size.height * 0.4f)
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF06B6D4).copy(alpha = 0.12f), Color.Transparent),
                        radius = size.width * 0.4f,
                        center = androidx.compose.ui.geometry.Offset(size.width * 0.75f, size.height * 0.3f)
                    )
                )
                drawContent()
            }
            .padding(24.dp),
        horizontalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // LEFT COLUMN: Dynamic microphone visualizer, system status and biometric security controls
        Column(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header for tablet display - Vox AI Immersive Style
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (isListening) Color(0xFF22D3EE) else Color(0xFF06B6D4))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Vox AI",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = (-0.5).sp
                        )
                    }
                    Text(
                        text = "Asistente Inteligente • Lenovo Tab",
                        fontSize = 13.sp,
                        color = Color(0xFFA1A1AA)
                    )
                }

                IconButton(
                    onClick = onTriggerSettings,
                    modifier = Modifier
                        .background(Color(0xFF1D1F24), CircleShape)
                        .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                        .size(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = Color.White.copy(alpha = 0.8f)
                    )
                }
            }

            // Centralized interactive orbital radar
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                // Large circular orbital paths
                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.05f), CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.03f), CircleShape)
                )

                if (isListening) {
                    // Reactive visual sonic wave rings
                    Box(
                        modifier = Modifier
                            .size(125.dp)
                            .scale(pulseScale + rmsValue * 0.5f)
                            .border(2.dp, Color(0xFF22D3EE).copy(alpha = pulseAlpha), CircleShape)
                    )
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .scale(pulseScale * 0.82f + rmsValue * 0.3f)
                            .border(1.dp, Color(0xFF3B82F6).copy(alpha = pulseAlpha * 0.6f), CircleShape)
                    )
                } else if (isProcessing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(90.dp),
                        color = Color(0xFF22D3EE),
                        strokeWidth = 3.5.dp
                    )
                }

                // Interaction Sphere
                Box(
                    modifier = Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF3B82F6),
                                    Color(0xFF06B6D4),
                                    Color(0xFF22D3EE)
                                )
                            )
                        )
                        .border(4.dp, Color.White.copy(alpha = 0.15f), CircleShape)
                        .clickable { onTriggerMic() }
                        .shadow(
                            elevation = 16.dp,
                            shape = CircleShape,
                            clip = false,
                            ambientColor = Color(0xFF06B6D4),
                            spotColor = Color(0xFF22D3EE)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                        contentDescription = "Pulsar para hablar",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            // Assistant response status card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF1D1F24),
                border = borderStroke(isListening || isProcessing)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = statusText,
                        fontSize = 16.sp,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    if (!isListening && !isProcessing) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Palabra clave de activación: \"$triggerWord\"",
                            fontSize = 11.sp,
                            color = Color(0xFFA1A1AA),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Scrollable Panel of Settings (Escucha Continua, Bio-Voz) inside left column
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 240.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Continuous Listening switch card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = if (isContinuousListening) Color(0xFF22D3EE).copy(alpha = 0.5f) else Color.White.copy(alpha = 0.05f),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .background(
                                            color = if (isContinuousListening) Color(0xFF22D3EE).copy(alpha = 0.15f) else Color.White.copy(alpha = 0.05f),
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isContinuousListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                                        contentDescription = null,
                                        tint = if (isContinuousListening) Color(0xFF22D3EE) else Color.White.copy(alpha = 0.4f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Escucha Continua (Manos Libres)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = if (isContinuousListening) "Dí \"$triggerWord\" en cualquier momento" else "Activación por pulsasión",
                                        fontSize = 10.sp,
                                        color = if (isContinuousListening) Color(0xFF22D3EE).copy(alpha = 0.8f) else Color(0xFFA1A1AA)
                                    )
                                }
                            }
                            Switch(
                                checked = isContinuousListening,
                                onCheckedChange = { onToggleContinuous(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color(0xFF22D3EE),
                                    checkedTrackColor = Color(0xFF22D3EE).copy(alpha = 0.3f),
                                    uncheckedThumbColor = Color(0xFFA1A1AA),
                                    uncheckedTrackColor = Color(0xFF161920)
                                )
                            )
                        }
                    }
                }

                // Speaker BioVoz protection card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = if (voiceIdEnabled) Color(0xFF10B981).copy(alpha = 0.5f) else Color.White.copy(alpha = 0.05f),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .background(
                                                color = if (voiceIdEnabled) Color(0xFF10B981).copy(alpha = 0.15f) else Color.White.copy(alpha = 0.05f),
                                                shape = CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (voiceIdEnabled) Icons.Default.Fingerprint else Icons.Default.Security,
                                            contentDescription = null,
                                            tint = if (voiceIdEnabled) Color(0xFF10B981) else Color.White.copy(alpha = 0.4f),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "Seguridad Bio-Voz",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = if (voiceIdRegistered) "Firma de: $voiceOwnerName" else "Desvinculada",
                                            fontSize = 10.sp,
                                            color = if (voiceIdEnabled) Color(0xFF10B981).copy(alpha = 0.8f) else Color(0xFFA1A1AA)
                                        )
                                    }
                                }
                                Switch(
                                    checked = voiceIdEnabled,
                                    onCheckedChange = { onToggleVoiceId(it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color(0xFF10B981),
                                        checkedTrackColor = Color(0xFF10B981).copy(alpha = 0.3f),
                                        uncheckedThumbColor = Color(0xFFA1A1AA),
                                        uncheckedTrackColor = Color(0xFF161920)
                                    )
                                )
                            }

                            if (voiceIdCalibrationStep > 0) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF0F1115), RoundedCornerShape(12.dp))
                                        .border(1.dp, Color(0xFF3B82F6).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                        .padding(10.dp)
                                ) {
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "🔴 MATRICULANDO... $voiceIdCalibrationStep/3",
                                                color = Color(0xFF3B82F6),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            TextButton(
                                                onClick = onCancelVoiceCalibration,
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text("CANCELAR", color = Color.Red, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = when (voiceIdCalibrationStep) {
                                                1 -> "Paso 1: Di \"$triggerWord\" con claridad..."
                                                2 -> "Paso 2: Repite \"$triggerWord\"..."
                                                else -> "Paso 3: Di \"$triggerWord\" una última vez..."
                                            },
                                            color = Color.White,
                                            fontSize = 11.sp
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        LinearProgressIndicator(
                                            progress = { voiceIdCalibrationStep / 3f },
                                            modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                            color = Color(0xFF3B82F6),
                                            trackColor = Color.White.copy(alpha = 0.05f)
                                        )
                                    }
                                }
                            } else if (voiceIdRegistered) {
                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Simular Intruso (Test)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("Comandos simulados de tercero", color = Color(0xFFA1A1AA), fontSize = 9.sp)
                                    }
                                    Switch(
                                        checked = simulateIntruder,
                                        onCheckedChange = { onToggleSimulateIntruder(it) },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color(0xFFEF4444),
                                            checkedTrackColor = Color(0xFFEF4444).copy(alpha = 0.3f),
                                            uncheckedThumbColor = Color(0xFFA1A1AA),
                                            uncheckedTrackColor = Color(0xFF161920)
                                        )
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    var ownerNameInput by remember { mutableStateOf(voiceOwnerName) }
                                    var isEditingName by remember { mutableStateOf(false) }
                                    
                                    if (isEditingName) {
                                        OutlinedTextField(
                                            value = ownerNameInput,
                                            onValueChange = { ownerNameInput = it },
                                            label = { Text("Propietario", fontSize = 9.sp, color = Color.Gray) },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f).height(44.dp),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedTextColor = Color.White,
                                                unfocusedTextColor = Color.White,
                                                focusedBorderColor = Color(0xFF10B981)
                                            )
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        IconButton(
                                            onClick = { 
                                                onUpdateVoiceOwnerName(ownerNameInput)
                                                isEditingName = false
                                            }
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = "Guardar", tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                                        }
                                    } else {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Propietario: ", color = Color(0xFFA1A1AA), fontSize = 11.sp)
                                            Text(voiceOwnerName, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                imageVector = Icons.Default.Edit,
                                                contentDescription = "Editar nombre",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(12.dp).clickable { isEditingName = true }
                                            )
                                        }
                                    }
                                    
                                    TextButton(
                                        onClick = onClearVoiceFingerprint,
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Text("RESETEAR FIRMA", color = Color(0xFFEF4444), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            } else if (voiceIdEnabled) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = onStartVoiceCalibration,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                                ) {
                                    Icon(Icons.Default.SettingsVoice, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Matricular Mi Huella de Voz", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // RIGHT COLUMN: Active tab views (INICIO, APPS, HISTORIAL) + Bottom Translucent navigation pill
        Column(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Container for active panel contents
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (selectedTab == 0) {
                    // INICIO Tab containing Prompt field and visual Quick access commands
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Keyboard input box
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = textCommandInput,
                                onValueChange = { textCommandInput = it },
                                placeholder = { Text("Escribe un comando...", color = Color(0xFFA1A1AA), fontSize = 13.sp) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = Color(0xFF06B6D4),
                                    unfocusedBorderColor = Color(0xFF2C2C35),
                                    focusedContainerColor = Color(0xFF111116),
                                    unfocusedContainerColor = Color(0xFF111116)
                                ),
                                shape = RoundedCornerShape(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            IconButton(
                                onClick = {
                                    if (textCommandInput.isNotBlank()) {
                                        keyboardController?.hide()
                                        onSendTextCommand(textCommandInput)
                                        textCommandInput = ""
                                    }
                                },
                                modifier = Modifier
                                    .size(50.dp)
                                    .background(Color(0xFF06B6D4), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Enviar",
                                    tint = Color.Black
                                )
                            }
                        }

                        // Grid headers
                        Text(
                            text = "Acciones Rápidas del Dispositivo:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF22D3EE),
                            modifier = Modifier.padding(bottom = 8.dp, start = 4.dp)
                        )

                        // 2x2 modular visual grid inside scroll column to ensure zero clipping
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Alarm
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(Color(0xFF1D1F24), RoundedCornerShape(16.dp))
                                            .border(1.dp, Color(0xFF06B6D4).copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                                            .clip(RoundedCornerShape(16.dp))
                                            .clickable { onSendTextCommand("Pon una de alarma a las 08:30") }
                                            .padding(14.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Notifications,
                                            contentDescription = null,
                                            tint = Color(0xFF06B6D4),
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("Alarma Rápida", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("Poner a las 08:30", color = Color(0xFFA1A1AA), fontSize = 11.sp)
                                    }

                                    // Note
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(Color(0xFF1D1F24), RoundedCornerShape(16.dp))
                                            .border(1.dp, Color(0xFFFACC15).copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                                            .clip(RoundedCornerShape(16.dp))
                                            .clickable { onSendTextCommand("Añade una nota: Tareas pendientes hoy") }
                                            .padding(14.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Notes,
                                            contentDescription = null,
                                            tint = Color(0xFFFACC15),
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("Nota Rápida", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("Escribir recordatorio", color = Color(0xFFA1A1AA), fontSize = 11.sp)
                                    }
                                }
                            }

                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Map
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(Color(0xFF1D1F24), RoundedCornerShape(16.dp))
                                            .border(1.dp, Color(0xFFF87171).copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                                            .clip(RoundedCornerShape(16.dp))
                                            .clickable { onSendTextCommand("Busca cafeterías cerca en el mapa") }
                                            .padding(14.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Map,
                                            contentDescription = null,
                                            tint = Color(0xFFF87171),
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("Ubicación Local", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("Mapa de puntos de interés", color = Color(0xFFA1A1AA), fontSize = 11.sp)
                                    }

                                    // Discord integrations
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(Color(0xFF1D1F24), RoundedCornerShape(16.dp))
                                            .border(1.dp, Color(0xFF5865F2).copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                                            .clip(RoundedCornerShape(16.dp))
                                            .clickable { onSendTextCommand("Mandar un discord Iniciando test del sistema") }
                                            .padding(14.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ChatBubble,
                                            contentDescription = null,
                                            tint = Color(0xFF5865F2),
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("Enviar Discord", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("Webhook de sincronización", color = Color(0xFFA1A1AA), fontSize = 11.sp)
                                    }
                                }
                            }

                            item {
                                Text(
                                    text = "Atajos de Voz Personalizados:",
                                    fontSize = 11.sp,
                                    color = Color(0xFFA1A1AA),
                                    modifier = Modifier.padding(top = 10.dp, start = 4.dp, bottom = 4.dp)
                                )
                            }

                            item {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val quickList = listOf(
                                        "Traduce al inglés: Buenos días, estoy listo" to (Icons.Default.Translate to Color(0xFF22D3EE)),
                                        "Llamar al número 600123456" to (Icons.Default.Call to Color(0xFF4ADE80)),
                                        "Abre youtube" to (Icons.AutoMirrored.Filled.Launch to Color(0xFFA78BFA))
                                    )

                                    quickList.forEach { (command, layoutVisual) ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFF161920), RoundedCornerShape(12.dp))
                                                .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                                .clip(RoundedCornerShape(12.dp))
                                                .clickable { onSendTextCommand(command) }
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = layoutVisual.first,
                                                contentDescription = null,
                                                tint = layoutVisual.second,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = command,
                                                color = Color.White.copy(alpha = 0.9f),
                                                fontSize = 12.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if (selectedTab == 1) {
                    // APPS Tab: displays apps and system packages to command launch by voice
                    var searchQuery by remember { mutableStateOf("") }
                    val filteredApps = remember(installedApps, searchQuery) {
                        if (searchQuery.isBlank()) {
                            installedApps
                        } else {
                            installedApps.filter { it.name.contains(searchQuery, ignoreCase = true) }
                        }
                    }

                    Column(modifier = Modifier.fillMaxSize()) {
                        Text(
                            text = "Aplicaciones del Sistema (${installedApps.size})",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Abre cualquier aplicación instalada: \"Abre Gmail\", \"Abre Spotify\"...",
                            fontSize = 11.sp,
                            color = Color(0xFFA1A1AA),
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Buscar aplicación...", color = Color(0xFFA1A1AA), fontSize = 12.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp)
                                .height(46.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF22D3EE),
                                unfocusedBorderColor = Color(0xFF2C2C35),
                                focusedContainerColor = Color(0xFF111116),
                                unfocusedContainerColor = Color(0xFF111116)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFFA1A1AA), modifier = Modifier.size(16.dp))
                            }
                        )

                        if (filteredApps.isEmpty()) {
                            Box(
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No se encontraron aplicaciones", color = Color(0xFFA1A1AA), fontSize = 13.sp)
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(filteredApps, key = { it.packageName }) { appInfo ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF161920), RoundedCornerShape(12.dp))
                                            .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { onLaunchApp(appInfo.packageName) }
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(36.dp)
                                                    .background(Color(0xFF22D3EE).copy(alpha = 0.1f), CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = appInfo.name.firstOrNull()?.toString()?.uppercase() ?: "",
                                                    color = Color(0xFF22D3EE),
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(appInfo.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                                Text(appInfo.packageName, color = Color(0xFFA1A1AA), fontSize = 10.sp, maxLines = 1)
                                            }
                                        }
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFF22D3EE).copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                        ) {
                                            Text("ABRIR", color = Color(0xFF22D3EE), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // HISTORIAL Tab: displays complete past history
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Historial del Asistente", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            if (commandsHistory.isNotEmpty()) {
                                Text(
                                    text = "Limpiar historial",
                                    fontSize = 13.sp,
                                    color = Color(0xFF22D3EE),
                                    modifier = Modifier.clickable { onClearHistory() }
                                )
                            }
                        }

                        if (commandsHistory.isEmpty()) {
                            Box(
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Info, contentDescription = "Vacío", tint = Color(0xFF2E3036), modifier = Modifier.size(48.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "No hay comandos guardados.\nDi \"$triggerWord\" o activa el micro para empezar.",
                                        fontSize = 13.sp,
                                        color = Color(0xFFA1A1AA),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(commandsHistory, key = { it.id }) { record ->
                                    HistoryCard(record = record)
                                }
                            }
                        }
                    }
                }
            }

            // Material 3 premium Translucent tablet navigation indicator pills at bottom of right column
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1D1F24).copy(alpha = 0.6f), RoundedCornerShape(24.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(24.dp))
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(
                    Triple(0, Icons.Default.Home, "INICIO"),
                    Triple(1, Icons.Default.Apps, "APPS"),
                    Triple(2, Icons.Default.History, "HISTORIAL")
                ).forEach { (index, iconVector, titleLabel) ->
                    Column(
                        modifier = Modifier
                            .clickable { selectedTab = index }
                            .padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .width(72.dp)
                                .height(32.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (selectedTab == index) Color(0xFFD0E4FF) else Color.Transparent),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = iconVector,
                                contentDescription = titleLabel,
                                tint = if (selectedTab == index) Color(0xFF001D36) else Color.White.copy(alpha = 0.5f)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = titleLabel,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedTab == index) Color(0xFFD0E4FF) else Color.White.copy(alpha = 0.5f)
                        )
                    }
                }

                // Decorative Music option
                Column(
                    modifier = Modifier
                        .clickable { 
                            selectedTab = 0
                            onSendTextCommand("Pon música relajante")
                        }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(72.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = "Música",
                            tint = Color.White.copy(alpha = 0.5f)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "MÚSICA",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.5f)
                    )
                }
            }
        }
    }
}
