package com.example.model

sealed class AssistantAction {
    data class SendEmail(val speech: String, val recipient: String, val subject: String, val body: String) : AssistantAction()
    data class SendDiscord(val speech: String, val message: String) : AssistantAction()
    data class SetAlarm(val speech: String, val hour: Int, val minute: Int, val label: String) : AssistantAction()
    data class PlayMusic(val speech: String, val query: String) : AssistantAction()
    data class CreateNote(val speech: String, val noteContent: String) : AssistantAction()
    data class OpenMap(val speech: String, val location: String) : AssistantAction()
    data class CallContact(val speech: String, val phoneNumber: String) : AssistantAction()
    data class OpenApp(val speech: String, val appOrUrl: String) : AssistantAction()
    data class TranslateText(val speech: String) : AssistantAction()
    data class SearchWeb(val speech: String, val searchQuery: String) : AssistantAction()
    data class GetWeather(val speech: String, val location: String) : AssistantAction()
    data class SetTimer(val speech: String, val durationSeconds: Int, val label: String) : AssistantAction()
    data class VoiceCalculate(val speech: String, val expression: String, val result: Double) : AssistantAction()
    data class AnalyzeScreen(val speech: String, val query: String) : AssistantAction()
    data class GeneralChat(val speech: String) : AssistantAction()
    data class Error(val error: String) : AssistantAction()
}
