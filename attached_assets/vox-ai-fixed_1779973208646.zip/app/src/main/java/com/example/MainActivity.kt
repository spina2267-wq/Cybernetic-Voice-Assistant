package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AssistantViewModel
import com.example.model.CommandRecord
import com.example.ui.TabletAssistantView
import kotlinx.coroutines.flow.MutableStateFlow
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    private val viewModel: AssistantViewModel by viewModels()
    private var speechRecognizer: SpeechRecognizer? = null
    private var isRecognizerListening = false
    private var restartListeningJob: kotlinx.coroutines.Job? = null
    
    // RMS sound levels for visualization in UI
    private val rmsLevel = MutableStateFlow(0f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Initialize SpeechRecognizer if available
        initSpeechRecognizer()

        setContent {
            MyApplicationTheme {
                val isListening by viewModel.isListening.collectAsState()
                val isContinuousListening by viewModel.isContinuousListening.collectAsState()
                val isProcessing by viewModel.isProcessing.collectAsState()
                val triggerWord by viewModel.triggerWord.collectAsState()
                val discordWebhook by viewModel.discordWebhook.collectAsState()
                val ttsEnabled by viewModel.ttsEnabled.collectAsState()
                val statusText by viewModel.statusText.collectAsState()
                val commandsHistory by viewModel.commandsHistory.collectAsState()
                val installedApps by viewModel.installedApps.collectAsState()
                val rmsState by rmsLevel.collectAsState()
                val speechTrigger by viewModel.speechRecognitionTrigger.collectAsState()

                // Voice ID biometric states
                val voiceIdEnabled by viewModel.voiceIdEnabled.collectAsState()
                val voiceIdRegistered by viewModel.voiceIdRegistered.collectAsState()
                val voiceIdCalibrationStep by viewModel.voiceIdCalibrationStep.collectAsState()
                val voiceOwnerName by viewModel.voiceOwnerName.collectAsState()
                val simulateIntruder by viewModel.simulateIntruder.collectAsState()
                val voiceShortcuts by viewModel.voiceShortcuts.collectAsState()
                val routines by viewModel.routines.collectAsState()
                val customMacros by viewModel.customMacros.collectAsState()

                val selectedImageUri by viewModel.selectedImageUri.collectAsState()
                val selectedImageBitmap by viewModel.selectedImageBitmap.collectAsState()

                val context = LocalContext.current

                // Launcher for selecting screenshots or images from the photo library/gallery
                val photoPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.GetContent()
                ) { uri ->
                    if (uri != null) {
                        try {
                            val inputStream = context.contentResolver.openInputStream(uri)
                            val bitmap = android.graphics.BitmapFactory.decodeStream(inputStream)
                            inputStream?.close()
                            if (bitmap != null) {
                                viewModel.setSelectedImage(bitmap, uri.toString())
                            } else {
                                Toast.makeText(context, "Error al descodificar la imagen", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "Error al leer el archivo de la imagen", Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                var shouldStartSpeechOnPermission by remember { mutableStateOf(false) }

                // Launcher for standard voice permissions
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    if (isGranted) {
                        if (shouldStartSpeechOnPermission) {
                            shouldStartSpeechOnPermission = false
                            startSpeechListening()
                        }
                    } else {
                        Toast.makeText(context, "Se necesita permiso de micrófono para reconocimiento de voz", Toast.LENGTH_LONG).show()
                    }
                }

                LaunchedEffect(Unit) {
                    viewModel.loadInstalledApps(context)
                    val hasPermission = ContextCompat.checkSelfPermission(
                        context, Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!hasPermission) {
                        shouldStartSpeechOnPermission = false
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }

                // Handle external reactive trigger for voice commands
                LaunchedEffect(speechTrigger) {
                    if (speechTrigger != null) {
                        viewModel.clearSpeechTrigger()
                        val hasPermission = ContextCompat.checkSelfPermission(
                            context, Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED

                        if (hasPermission) {
                            startSpeechListening()
                        } else {
                            shouldStartSpeechOnPermission = true
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                }

                // Cancel voice recognition immediately when hands-free continuous listening is turned off
                LaunchedEffect(isContinuousListening) {
                    if (!isContinuousListening) {
                        try {
                            restartListeningJob?.cancel()
                            speechRecognizer?.cancel()
                            isRecognizerListening = false
                            viewModel.setListening(false)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }

                // Cancel voice recognition when the assistant begins speaking to prevent echo-loops
                val isSpeaking by viewModel.isSpeaking.collectAsState()
                LaunchedEffect(isSpeaking) {
                    if (isSpeaking) {
                        try {
                            restartListeningJob?.cancel()
                            speechRecognizer?.cancel()
                            isRecognizerListening = false
                            viewModel.setListening(false)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    AssistantMainView(
                        modifier = Modifier.padding(innerPadding),
                        isListening = isListening,
                        isContinuousListening = isContinuousListening,
                        onToggleContinuous = { enabled ->
                            viewModel.setContinuousListening(enabled)
                        },
                        isProcessing = isProcessing,
                        triggerWord = triggerWord,
                        discordWebhook = discordWebhook,
                        ttsEnabled = ttsEnabled,
                        statusText = statusText,
                        commandsHistory = commandsHistory,
                        rmsValue = rmsState,
                        onTriggerMic = {
                            viewModel.triggerSpeechRecognition()
                        },
                        onSendTextCommand = { query ->
                            viewModel.processVoiceCommand(query, context)
                        },
                        onUpdateTriggerWord = { word ->
                            viewModel.setTriggerWord(word)
                        },
                        onUpdateDiscordWebhook = { url ->
                            viewModel.setDiscordWebhook(url)
                        },
                        onToggleTts = { enabled ->
                            viewModel.setTtsEnabled(enabled)
                        },
                        onClearHistory = {
                            viewModel.clearHistory()
                        },
                        installedApps = installedApps,
                        onLaunchApp = { packageName ->
                            viewModel.launchAppByPackage(context, packageName)
                        },
                        voiceIdEnabled = voiceIdEnabled,
                        voiceIdRegistered = voiceIdRegistered,
                        voiceIdCalibrationStep = voiceIdCalibrationStep,
                        voiceOwnerName = voiceOwnerName,
                        simulateIntruder = simulateIntruder,
                        onToggleVoiceId = { enabled ->
                            viewModel.setVoiceIdEnabled(enabled)
                        },
                        onToggleSimulateIntruder = { simulate ->
                            viewModel.setSimulateIntruder(simulate)
                        },
                        onUpdateVoiceOwnerName = { name ->
                            viewModel.setVoiceOwnerName(name)
                        },
                        onStartVoiceCalibration = {
                            viewModel.startVoiceIdCalibration()
                        },
                        onCancelVoiceCalibration = {
                            viewModel.cancelVoiceIdCalibration()
                        },
                        onClearVoiceFingerprint = {
                            viewModel.clearVoiceFingerprint()
                        },
                        voiceShortcuts = voiceShortcuts,
                        onAddVoiceShortcut = { phrase, url ->
                            viewModel.addVoiceShortcut(phrase, url)
                        },
                        onDeleteVoiceShortcut = { phrase ->
                            viewModel.deleteVoiceShortcut(phrase)
                        },
                        routines = routines,
                        onAddRoutine = { name, time, command ->
                            viewModel.addRoutine(name, time, command)
                        },
                        onToggleRoutine = { id, enabled ->
                            viewModel.toggleRoutine(id, enabled)
                        },
                        onDeleteRoutine = { id ->
                            viewModel.deleteRoutine(id)
                        },
                        customMacros = customMacros,
                        onAddCustomMacro = { trigger, commands ->
                            viewModel.addCustomMacro(trigger, commands)
                        },
                        onToggleCustomMacro = { id, enabled ->
                            viewModel.toggleCustomMacro(id, enabled)
                        },
                        onDeleteCustomMacro = { id ->
                            viewModel.deleteCustomMacro(id)
                        },
                        selectedImageUri = selectedImageUri,
                        selectedImageBitmap = selectedImageBitmap,
                        onPickImage = { photoPickerLauncher.launch("image/*") },
                        onClearSelectedImage = { viewModel.clearSelectedImage() },
                        onTriggerAnalyzeScreen = { viewModel.processVoiceCommand("analiza mi pantalla", context) }
                    )
                }
            }
        }
    }

    private fun initSpeechRecognizer() {
        if (isFinishing || isDestroyed) return
        try {
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            isRecognizerListening = true
                            viewModel.setListening(true)
                            rmsLevel.value = 0f
                        }

                        override fun onBeginningOfSpeech() {}

                        override fun onRmsChanged(rmsdB: Float) {
                            // Map rmsdB value (usually negative or small values) to readable visual scale
                            val normalized = (rmsdB + 2f).coerceAtLeast(0f) / 10f
                            rmsLevel.value = normalized.coerceIn(0f, 1f)
                        }

                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            isRecognizerListening = false
                            viewModel.setListening(false)
                        }

                        override fun onError(error: Int) {
                            isRecognizerListening = false
                            viewModel.setListening(false)
                            val errorMsg = when (error) {
                                SpeechRecognizer.ERROR_AUDIO -> "Error de audio"
                                SpeechRecognizer.ERROR_CLIENT -> "Error de servicio local"
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Faltan permisos"
                                SpeechRecognizer.ERROR_NETWORK -> "Fallo de conexión"
                                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Tiempo de red agotado"
                                SpeechRecognizer.ERROR_NO_MATCH -> "No entendí, intenta de nuevo"
                                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Servicio de voz ocupado"
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No escuché nada"
                                else -> "Vuelve a intentarlo..."
                            }
                            Toast.makeText(this@MainActivity, errorMsg, Toast.LENGTH_SHORT).show()

                            // Auto-restart listening securely via cancellable job if continuous hands-free mode is active
                            if (viewModel.isContinuousListening.value && !viewModel.isProcessing.value && !viewModel.isSpeaking.value) {
                                val delayMs = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 2000L else 1000L
                                scheduleSpeechListeningRestart(delayMs)
                            }
                        }

                        override fun onResults(results: Bundle?) {
                            isRecognizerListening = false
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            if (!matches.isNullOrEmpty()) {
                                val speechText = matches[0]
                                viewModel.processVoiceCommand(speechText, this@MainActivity)
                            } else {
                                if (viewModel.isContinuousListening.value && !viewModel.isProcessing.value && !viewModel.isSpeaking.value) {
                                    scheduleSpeechListeningRestart(1000L)
                                }
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {}

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            } else {
                android.util.Log.w("MainActivity", "El reconocimiento de voz no está disponible en este dispositivo.")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            android.util.Log.e("MainActivity", "Error al inicializar el reconocedor de voz", e)
            speechRecognizer = null
        }
    }

    private fun scheduleSpeechListeningRestart(delayMs: Long) {
        if (isFinishing || isDestroyed) return
        restartListeningJob?.cancel()
        restartListeningJob = lifecycleScope.launch {
            delay(delayMs)
            if (viewModel.isContinuousListening.value && !viewModel.isProcessing.value && !viewModel.isSpeaking.value) {
                startSpeechListening()
            }
        }
    }

    private fun startSpeechListening() {
        if (isFinishing || isDestroyed) return
        
        val hasPermission = androidx.core.content.ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        
        if (!hasPermission) {
            if (viewModel.isContinuousListening.value) {
                viewModel.setContinuousListening(false)
                Toast.makeText(this, "Permiso de micrófono no otorgado. Desactivando manos libres.", Toast.LENGTH_LONG).show()
            }
            return
        }

        if (isRecognizerListening || viewModel.isProcessing.value || viewModel.isSpeaking.value) {
            return
        }
        try {
            if (speechRecognizer == null) {
                initSpeechRecognizer()
            }
            
            if (speechRecognizer != null) {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                isRecognizerListening = true
                speechRecognizer?.startListening(intent)
            } else {
                Toast.makeText(this, "El reconocimiento de voz no está habilitado en este dispositivo", Toast.LENGTH_SHORT).show()
                isRecognizerListening = false
                viewModel.setListening(false)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            isRecognizerListening = false
            viewModel.setListening(false)
            Toast.makeText(this, "No se pudo iniciar el micrófono de forma interactiva: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.setAppInForeground(true)
    }

    override fun onStop() {
        super.onStop()
        viewModel.setAppInForeground(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            restartListeningJob?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        speechRecognizer = null
    }
}

@Composable
fun AssistantMainView(
    modifier: Modifier = Modifier,
    isListening: Boolean,
    isContinuousListening: Boolean,
    onToggleContinuous: (Boolean) -> Unit,
    isProcessing: Boolean,
    triggerWord: String,
    discordWebhook: String,
    ttsEnabled: Boolean,
    statusText: String,
    commandsHistory: List<com.example.model.CommandRecord>,
    rmsValue: Float,
    onTriggerMic: () -> Unit,
    onSendTextCommand: (String) -> Unit,
    onUpdateTriggerWord: (String) -> Unit,
    onUpdateDiscordWebhook: (String) -> Unit,
    onToggleTts: (Boolean) -> Unit,
    onClearHistory: () -> Unit,
    installedApps: List<com.example.model.AppInfo>,
    onLaunchApp: (String) -> Unit,
    voiceIdEnabled: Boolean,
    voiceIdRegistered: Boolean,
    voiceIdCalibrationStep: Int,
    voiceOwnerName: String,
    simulateIntruder: Boolean,
    onToggleVoiceId: (Boolean) -> Unit,
    onToggleSimulateIntruder: (Boolean) -> Unit,
    onUpdateVoiceOwnerName: (String) -> Unit,
    onStartVoiceCalibration: () -> Unit,
    onCancelVoiceCalibration: () -> Unit,
    onClearVoiceFingerprint: () -> Unit,
    voiceShortcuts: Map<String, String> = emptyMap(),
    onAddVoiceShortcut: (String, String) -> Unit = { _, _ -> },
    onDeleteVoiceShortcut: (String) -> Unit = {},
    routines: List<com.example.model.Routine> = emptyList(),
    onAddRoutine: (String, String, String) -> Unit = { _, _, _ -> },
    onToggleRoutine: (String, Boolean) -> Unit = { _, _ -> },
    onDeleteRoutine: (String) -> Unit = {},
    customMacros: List<com.example.model.CustomMacro> = emptyList(),
    onAddCustomMacro: (String, List<String>) -> Unit = { _, _ -> },
    onToggleCustomMacro: (String, Boolean) -> Unit = { _, _ -> },
    onDeleteCustomMacro: (String) -> Unit = {},
    selectedImageUri: String? = null,
    selectedImageBitmap: android.graphics.Bitmap? = null,
    onPickImage: () -> Unit = {},
    onClearSelectedImage: () -> Unit = {},
    onTriggerAnalyzeScreen: () -> Unit = {}
) {
    val configuration = LocalConfiguration.current
    val isWide = configuration.screenWidthDp >= 720

    var showSettings by remember { mutableStateOf(false) }

    if (isWide) {
        TabletAssistantView(
            modifier = modifier,
            isListening = isListening,
            isContinuousListening = isContinuousListening,
            onToggleContinuous = onToggleContinuous,
            isProcessing = isProcessing,
            triggerWord = triggerWord,
            discordWebhook = discordWebhook,
            ttsEnabled = ttsEnabled,
            statusText = statusText,
            commandsHistory = commandsHistory,
            rmsValue = rmsValue,
            onTriggerMic = onTriggerMic,
            onSendTextCommand = onSendTextCommand,
            onUpdateTriggerWord = onUpdateTriggerWord,
            onUpdateDiscordWebhook = onUpdateDiscordWebhook,
            onToggleTts = onToggleTts,
            onClearHistory = onClearHistory,
            installedApps = installedApps,
            onLaunchApp = onLaunchApp,
            voiceIdEnabled = voiceIdEnabled,
            voiceIdRegistered = voiceIdRegistered,
            voiceIdCalibrationStep = voiceIdCalibrationStep,
            voiceOwnerName = voiceOwnerName,
            simulateIntruder = simulateIntruder,
            onToggleVoiceId = onToggleVoiceId,
            onToggleSimulateIntruder = onToggleSimulateIntruder,
            onUpdateVoiceOwnerName = onUpdateVoiceOwnerName,
            onStartVoiceCalibration = onStartVoiceCalibration,
            onCancelVoiceCalibration = onCancelVoiceCalibration,
            onClearVoiceFingerprint = onClearVoiceFingerprint,
            onTriggerSettings = { showSettings = true },
            routines = routines,
            onAddRoutine = onAddRoutine,
            onToggleRoutine = onToggleRoutine,
            onDeleteRoutine = onDeleteRoutine,
            customMacros = customMacros,
            onAddCustomMacro = onAddCustomMacro,
            onToggleCustomMacro = onToggleCustomMacro,
            onDeleteCustomMacro = onDeleteCustomMacro
        )

        if (showSettings) {
            SettingsDialog(
                currentWord = triggerWord,
                currentWebhook = discordWebhook,
                ttsEnabled = ttsEnabled,
                onDismiss = { showSettings = false },
                onSave = { word, webhook, tts ->
                    onUpdateTriggerWord(word)
                    onUpdateDiscordWebhook(webhook)
                    onToggleTts(tts)
                    showSettings = false
                }
            )
        }
    } else {
        MobileAssistantView(
            modifier = modifier,
            isListening = isListening,
            isContinuousListening = isContinuousListening,
            onToggleContinuous = onToggleContinuous,
            isProcessing = isProcessing,
            triggerWord = triggerWord,
            discordWebhook = discordWebhook,
            ttsEnabled = ttsEnabled,
            statusText = statusText,
            commandsHistory = commandsHistory,
            rmsValue = rmsValue,
            onTriggerMic = onTriggerMic,
            onSendTextCommand = onSendTextCommand,
            onUpdateTriggerWord = onUpdateTriggerWord,
            onUpdateDiscordWebhook = onUpdateDiscordWebhook,
            onToggleTts = onToggleTts,
            onClearHistory = onClearHistory,
            installedApps = installedApps,
            onLaunchApp = onLaunchApp,
            voiceIdEnabled = voiceIdEnabled,
            voiceIdRegistered = voiceIdRegistered,
            voiceIdCalibrationStep = voiceIdCalibrationStep,
            voiceOwnerName = voiceOwnerName,
            simulateIntruder = simulateIntruder,
            onToggleVoiceId = onToggleVoiceId,
            onToggleSimulateIntruder = onToggleSimulateIntruder,
            onUpdateVoiceOwnerName = onUpdateVoiceOwnerName,
            onStartVoiceCalibration = onStartVoiceCalibration,
            onCancelVoiceCalibration = onCancelVoiceCalibration,
            onClearVoiceFingerprint = onClearVoiceFingerprint,
            voiceShortcuts = voiceShortcuts,
            onAddVoiceShortcut = onAddVoiceShortcut,
            onDeleteVoiceShortcut = onDeleteVoiceShortcut,
            routines = routines,
            onAddRoutine = onAddRoutine,
            onToggleRoutine = onToggleRoutine,
            onDeleteRoutine = onDeleteRoutine,
            customMacros = customMacros,
            onAddCustomMacro = onAddCustomMacro,
            onToggleCustomMacro = onToggleCustomMacro,
            onDeleteCustomMacro = onDeleteCustomMacro,
            selectedImageUri = selectedImageUri,
            selectedImageBitmap = selectedImageBitmap,
            onPickImage = onPickImage,
            onClearSelectedImage = onClearSelectedImage,
            onTriggerAnalyzeScreen = onTriggerAnalyzeScreen
        )
    }
}

@Composable
fun MobileAssistantView(
    modifier: Modifier = Modifier,
    isListening: Boolean,
    isContinuousListening: Boolean,
    onToggleContinuous: (Boolean) -> Unit,
    isProcessing: Boolean,
    triggerWord: String,
    discordWebhook: String,
    ttsEnabled: Boolean,
    statusText: String,
    commandsHistory: List<com.example.model.CommandRecord>,
    rmsValue: Float,
    onTriggerMic: () -> Unit,
    onSendTextCommand: (String) -> Unit,
    onUpdateTriggerWord: (String) -> Unit,
    onUpdateDiscordWebhook: (String) -> Unit,
    onToggleTts: (Boolean) -> Unit,
    onClearHistory: () -> Unit,
    installedApps: List<com.example.model.AppInfo>,
    onLaunchApp: (String) -> Unit,
    voiceIdEnabled: Boolean,
    voiceIdRegistered: Boolean,
    voiceIdCalibrationStep: Int,
    voiceOwnerName: String,
    simulateIntruder: Boolean,
    onToggleVoiceId: (Boolean) -> Unit,
    onToggleSimulateIntruder: (Boolean) -> Unit,
    onUpdateVoiceOwnerName: (String) -> Unit,
    onStartVoiceCalibration: () -> Unit,
    onCancelVoiceCalibration: () -> Unit,
    onClearVoiceFingerprint: () -> Unit,
    voiceShortcuts: Map<String, String> = emptyMap(),
    onAddVoiceShortcut: (String, String) -> Unit = { _, _ -> },
    onDeleteVoiceShortcut: (String) -> Unit = {},
    routines: List<com.example.model.Routine> = emptyList(),
    onAddRoutine: (String, String, String) -> Unit = { _, _, _ -> },
    onToggleRoutine: (String, Boolean) -> Unit = { _, _ -> },
    onDeleteRoutine: (String) -> Unit = {},
    customMacros: List<com.example.model.CustomMacro> = emptyList(),
    onAddCustomMacro: (String, List<String>) -> Unit = { _, _ -> },
    onToggleCustomMacro: (String, Boolean) -> Unit = { _, _ -> },
    onDeleteCustomMacro: (String) -> Unit = {},
    selectedImageUri: String? = null,
    selectedImageBitmap: android.graphics.Bitmap? = null,
    onPickImage: () -> Unit = {},
    onClearSelectedImage: () -> Unit = {},
    onTriggerAnalyzeScreen: () -> Unit = {}
) {
    var showAddShortcutDialog by remember { mutableStateOf(false) }
    var newShortcutKey by remember { mutableStateOf("") }
    var newShortcutUrl by remember { mutableStateOf("") }

    var showSettings by remember { mutableStateOf(false) }
    var textCommandInput by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    // Infinite animation transition for pulsing visual ring effect
    val infiniteTransition = rememberInfiniteTransition(label = "RadarCircle")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "alpha"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F1115))
            .drawWithContent {
                // Soft elegant backing glow spheres mimicking blur tailwind effects
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF3B82F6).copy(alpha = 0.18f), Color.Transparent),
                        radius = size.width * 0.65f,
                        center = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.35f)
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF06B6D4).copy(alpha = 0.15f), Color.Transparent),
                        radius = size.width * 0.55f,
                        center = androidx.compose.ui.geometry.Offset(size.width * 0.4f, size.height * 0.25f)
                    )
                )
                drawContent()
            }
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Header - Custom Vox AI Immersive Style
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isListening) Color(0xFF22D3EE) else Color(0xFF06B6D4))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Vox AI",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = (-0.5).sp
                    )
                }
                Text(
                    text = "Asistente siempre activo",
                    fontSize = 13.sp,
                    color = Color(0xFFA1A1AA)
                )
            }

            IconButton(
                onClick = { showSettings = true },
                modifier = Modifier
                    .background(Color(0xFF1D1F24), CircleShape)
                    .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                    .size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = Color.White.copy(alpha = 0.8f)
                )
            }
        }

        // Main Visualizer Area with Orbit Rings and Pulse Glow
        Box(
            modifier = Modifier
                .height(210.dp)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            // Orbit Rings
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .border(1.dp, Color.White.copy(alpha = 0.05f), CircleShape)
            )
            Box(
                modifier = Modifier
                    .size(210.dp)
                    .border(1.dp, Color.White.copy(alpha = 0.03f), CircleShape)
            )

            if (isListening) {
                // Sonic interactive feedback waves
                Box(
                    modifier = Modifier
                        .size(135.dp)
                        .scale(pulseScale + rmsValue * 0.5f)
                        .border(2.dp, Color(0xFF22D3EE).copy(alpha = pulseAlpha), CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(165.dp)
                        .scale(pulseScale * 0.8f + rmsValue * 0.3f)
                        .border(1.dp, Color(0xFF3B82F6).copy(alpha = pulseAlpha * 0.6f), CircleShape)
                )
            } else if (isProcessing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(105.dp),
                    color = Color(0xFF22D3EE),
                    strokeWidth = 3.dp
                )
            }

            // Central Glowing Sphere: gradient to-tr from-[#3B82F6] via-[#06B6D4] to-[#22D3EE]
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF3B82F6),
                                Color(0xFF06B6D4),
                                Color(0xFF22D3EE)
                            )
                        )
                    )
                    .border(4.dp, Color.White.copy(alpha = 0.15f), CircleShape)
                    .clickable { onTriggerMic() }
                    .shadow(elevation = 20.dp, shape = CircleShape, clip = false, ambientColor = Color(0xFF06B6D4), spotColor = Color(0xFF22D3EE)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                    contentDescription = "Pulsar para hablar",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        // Real-time Status and Response Field
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFF1D1F24),
            border = borderStroke(isListening || isProcessing)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = statusText,
                    fontSize = 15.sp,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.fillMaxWidth()
                )
                
                if (!isListening && !isProcessing) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Palabra de activación: \"$triggerWord\"",
                        fontSize = 11.sp,
                        color = Color(0xFFA1A1AA),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Hands-Free Continuous Voice Activation Switch
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .border(
                    width = 1.dp,
                    color = if (isContinuousListening) Color(0xFF22D3EE).copy(alpha = 0.5f) else Color.White.copy(alpha = 0.05f),
                    shape = RoundedCornerShape(16.dp)
                ),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161920))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                color = if (isContinuousListening) Color(0xFF22D3EE).copy(alpha = 0.15f) else Color.White.copy(alpha = 0.05f),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isContinuousListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                            contentDescription = null,
                            tint = if (isContinuousListening) Color(0xFF22D3EE) else Color.White.copy(alpha = 0.4f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Escucha de Voz Continua (Manos Libres)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = if (isContinuousListening) "Di \"$triggerWord\" y tu petición..." else "Llámame solo por voz",
                            fontSize = 10.sp,
                            color = if (isContinuousListening) Color(0xFF22D3EE).copy(alpha = 0.8f) else Color(0xFFA1A1AA)
                        )
                    }
                }
                Switch(
                    checked = isContinuousListening,
                    onCheckedChange = { onToggleContinuous(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF22D3EE),
                        checkedTrackColor = Color(0xFF22D3EE).copy(alpha = 0.3f),
                        uncheckedThumbColor = Color(0xFFA1A1AA),
                        uncheckedTrackColor = Color(0xFF161920)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Card of Voice Biometry / Speaker Identification (Bio-Voz)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .border(
                    width = 1.dp,
                    color = if (voiceIdEnabled) Color(0xFF10B981).copy(alpha = 0.5f) else Color.White.copy(alpha = 0.05f),
                    shape = RoundedCornerShape(16.dp)
                ),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161920))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    color = if (voiceIdEnabled) Color(0xFF10B981).copy(alpha = 0.15f) else Color.White.copy(alpha = 0.05f),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (voiceIdEnabled) Icons.Default.Fingerprint else Icons.Default.Security,
                                contentDescription = null,
                                tint = if (voiceIdEnabled) Color(0xFF10B981) else Color.White.copy(alpha = 0.4f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Seguridad Bio-Voz (Solo Mi Voz)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = if (voiceIdRegistered) "Firma registrada de: $voiceOwnerName" else "Asistente protegido biométricamente",
                                fontSize = 10.sp,
                                color = if (voiceIdEnabled) Color(0xFF10B981).copy(alpha = 0.8f) else Color(0xFFA1A1AA)
                            )
                        }
                    }
                    Switch(
                        checked = voiceIdEnabled,
                        onCheckedChange = { onToggleVoiceId(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF10B981),
                            checkedTrackColor = Color(0xFF10B981).copy(alpha = 0.3f),
                            uncheckedThumbColor = Color(0xFFA1A1AA),
                            uncheckedTrackColor = Color(0xFF161920)
                        )
                    )
                }

                // If calibration is in progress
                if (voiceIdCalibrationStep > 0) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F1115), RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0xFF3B82F6).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🔴 CALIBRANDO HUELLA DIRECTA... $voiceIdCalibrationStep/3",
                                    color = Color(0xFF3B82F6),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                TextButton(
                                    onClick = onCancelVoiceCalibration,
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("CANCELAR", color = Color.Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = when (voiceIdCalibrationStep) {
                                    1 -> "Paso 1: Di \"$triggerWord\" con claridad..."
                                    2 -> "Paso 2: Di \"$triggerWord\" otra vez para calibrar..."
                                    else -> "Paso 3: Di \"$triggerWord\" por última vez para almacenar tu timbre..."
                                },
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            
                            // Visual Audio Wave simulator representing biometrical feature mapping
                            LinearProgressIndicator(
                                progress = { voiceIdCalibrationStep / 3f },
                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                color = Color(0xFF3B82F6),
                                trackColor = Color.White.copy(alpha = 0.05f)
                            )
                        }
                    }
                } else if (voiceIdRegistered) {
                    // Show voice calibration options, reset fingerprint and Simulate intruder switcher
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = Color.White.copy(alpha = 0.05f))
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Simular Intruso (Para Pruebas)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Simula comandos procedentes de otra persona para testear el bloqueo de voz.", color = Color(0xFFA1A1AA), fontSize = 9.sp)
                        }
                        Switch(
                            checked = simulateIntruder,
                            onCheckedChange = { onToggleSimulateIntruder(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFFEF4444),
                                checkedTrackColor = Color(0xFFEF4444).copy(alpha = 0.3f),
                                uncheckedThumbColor = Color(0xFFA1A1AA),
                                uncheckedTrackColor = Color(0xFF161920)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        var ownerNameInput by remember { mutableStateOf(voiceOwnerName) }
                        var isEditingName by remember { mutableStateOf(false) }
                        
                        if (isEditingName) {
                            OutlinedTextField(
                                value = ownerNameInput,
                                onValueChange = { ownerNameInput = it },
                                label = { Text("Nombre Propietario", fontSize = 10.sp, color = Color.Gray) },
                                singleLine = true,
                                modifier = Modifier.weight(1f).height(48.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = Color(0xFF10B981)
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = { 
                                    onUpdateVoiceOwnerName(ownerNameInput)
                                    isEditingName = false
                                }
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Guardar", tint = Color(0xFF10B981))
                            }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Propietario: ", color = Color(0xFFA1A1AA), fontSize = 11.sp)
                                Text(voiceOwnerName, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Editar nombre",
                                    tint = Color.Gray,
                                    modifier = Modifier.size(12.dp).clickable { isEditingName = true }
                                )
                            }
                        }
                        
                        TextButton(
                            onClick = onClearVoiceFingerprint,
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("BORRAR FIRMA VOZ", color = Color(0xFFEF4444), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else if (voiceIdEnabled) {
                    // Enabled but not registered. Prompt to register!
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onStartVoiceCalibration,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                    ) {
                        Icon(Icons.Default.SettingsVoice, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Matricular Mi Huella de Voz", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // State-driven premium Tab container
        var selectedTab by remember { mutableStateOf(0) } // 0: INICIO, 1: HISTORIAL

        Column(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            if (selectedTab == 0) {
                // INICIO Tab - Interactive controls and commands helper
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Previews selected attachment prior to analyzer prompt
                    SelectedImagePreview(
                        bitmap = selectedImageBitmap,
                        onClear = onClearSelectedImage,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Direct Text input as solid accessibility fallback
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = textCommandInput,
                            onValueChange = { textCommandInput = it },
                            placeholder = { Text("Escribe o pide algo...", color = Color(0xFFA1A1AA), fontSize = 13.sp) },
                            singleLine = true,
                            leadingIcon = {
                                IconButton(onClick = onPickImage) {
                                    Icon(
                                        imageVector = Icons.Default.Image,
                                        contentDescription = "Cargar Imagen",
                                        tint = Color(0xFF06B6D4)
                                    )
                                }
                            },
                            trailingIcon = {
                                IconButton(onClick = onTriggerAnalyzeScreen) {
                                    Icon(
                                        imageVector = Icons.Default.CameraAlt,
                                        contentDescription = "Analizar Pantalla",
                                        tint = Color(0xFF22D3EE)
                                    )
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF06B6D4),
                                unfocusedBorderColor = Color(0xFF2C2C35),
                                focusedContainerColor = Color(0xFF111116),
                                unfocusedContainerColor = Color(0xFF111116)
                            ),
                            shape = RoundedCornerShape(26.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                keyboardController?.hide()
                                onSendTextCommand(textCommandInput)
                                textCommandInput = ""
                            },
                            modifier = Modifier
                                .size(50.dp)
                                .background(Color(0xFF06B6D4), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Enviar",
                                tint = Color.Black
                            )
                        }
                    }

                    // Suggested shortcuts (Matching exact design classes bg-[#2D3038])
                    Text(
                        text = "Panel de Acceso Rápido:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF22D3EE),
                        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                    )

                    // 2x2 grid of quick access cards
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Alarm Tile
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Color(0xFF1D1F24), RoundedCornerShape(16.dp))
                                    .border(1.dp, Color(0xFF06B6D4).copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { onSendTextCommand("Pon una de alarma a las 08:30") }
                                    .padding(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = null,
                                    tint = Color(0xFF06B6D4),
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Alarma Rápida", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Poner a las 08:30", color = Color(0xFFA1A1AA), fontSize = 10.sp)
                            }

                            // Note Tile
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Color(0xFF1D1F24), RoundedCornerShape(16.dp))
                                    .border(1.dp, Color(0xFFFACC15).copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { onSendTextCommand("Añade una nota: Tareas pendientes hoy") }
                                    .padding(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notes,
                                    contentDescription = null,
                                    tint = Color(0xFFFACC15),
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Nota Rápida", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Escribir recordatorio", color = Color(0xFFA1A1AA), fontSize = 10.sp)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Map Tile
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Color(0xFF1D1F24), RoundedCornerShape(16.dp))
                                    .border(1.dp, Color(0xFFF87171).copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { onSendTextCommand("Busca cafeterías cerca en el mapa") }
                                    .padding(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Map,
                                    contentDescription = null,
                                    tint = Color(0xFFF87171),
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Buscar Cerca", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Mostrar mapa local", color = Color(0xFFA1A1AA), fontSize = 10.sp)
                            }

                            // Discord Tile
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Color(0xFF1D1F24), RoundedCornerShape(16.dp))
                                    .border(1.dp, Color(0xFF5865F2).copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { onSendTextCommand("Mandar un discord Iniciando test del sistema") }
                                    .padding(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ChatBubble,
                                    contentDescription = null,
                                    tint = Color(0xFF5865F2),
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Enviar Discord", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Registrar en canal", color = Color(0xFFA1A1AA), fontSize = 10.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // More suggested matches
                    Text(
                        text = "Otros Comandos de Interés:",
                        fontSize = 11.sp,
                        color = Color(0xFFA1A1AA),
                        modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
                    )
                    
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val suggestions = listOf(
                            "Traduce al inglés: Buenos días, estoy listo" to (Icons.Default.Translate to Color(0xFF22D3EE)),
                            "Llamar al número 600123456" to (Icons.Default.Call to Color(0xFF4ADE80)),
                            "Abre youtube" to (Icons.Default.Launch to Color(0xFFA78BFA))
                        )

                        suggestions.forEach { (command, visual) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF161920), RoundedCornerShape(12.dp))
                                    .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onSendTextCommand(command) }
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = visual.first,
                                    contentDescription = null,
                                    tint = visual.second,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = command,
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Title with Add Button
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Mis Atajos de Voz:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF22D3EE)
                            )
                            Text(
                                text = "Di el nombre para abrir el enlace directo",
                                fontSize = 10.sp,
                                color = Color(0xFFA1A1AA)
                            )
                        }
                        IconButton(
                            onClick = { showAddShortcutDialog = true },
                            modifier = Modifier
                                .background(Color(0xFF06B6D4).copy(alpha = 0.15f), CircleShape)
                                .size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Añadir Atajo",
                                tint = Color(0xFF22D3EE),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (voiceShortcuts.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF161920), RoundedCornerShape(12.dp))
                                .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No tienes atajos guardados.\nToca '+' para añadir el primero (ej: clase de ingles).",
                                color = Color(0xFFA1A1AA),
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            voiceShortcuts.forEach { (phrase, url) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF161920), RoundedCornerShape(14.dp))
                                        .border(1.dp, Color.White.copy(alpha = 0.04f), RoundedCornerShape(14.dp))
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable { 
                                            // Act like they spoke the command! This is highly visual & helpful for testing
                                            onSendTextCommand(phrase)
                                        }
                                        .padding(vertical = 10.dp, horizontal = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF22D3EE).copy(alpha = 0.1f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Link,
                                                contentDescription = null,
                                                tint = Color(0xFF22D3EE),
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = phrase,
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = url,
                                                color = Color(0xFFA1A1AA),
                                                fontSize = 10.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    IconButton(
                                        onClick = { onDeleteVoiceShortcut(phrase) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Borrar Atajo",
                                            tint = Color(0xFFEF4444).copy(alpha = 0.8f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (selectedTab == 1) {
                // APLICACIONES Tab - Dynamic list of all system apps
                var searchQuery by remember { mutableStateOf("") }
                val filteredApps = remember(installedApps, searchQuery) {
                    if (searchQuery.isBlank()) {
                        installedApps
                    } else {
                        installedApps.filter { it.name.contains(searchQuery, ignoreCase = true) }
                    }
                }

                Column(modifier = Modifier.fillMaxSize()) {
                    Text(
                        text = "Aplicaciones del Dispositivo (${installedApps.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                    Text(
                        text = "Controla cualquier app con tu voz: \"Abre Gmail\", \"Abre Spotify\"...",
                        fontSize = 11.sp,
                        color = Color(0xFFA1A1AA),
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    // Real-time app query search box
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Buscar aplicación...", color = Color(0xFFA1A1AA), fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .height(48.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF22D3EE),
                            unfocusedBorderColor = Color(0xFF2C2C35),
                            focusedContainerColor = Color(0xFF111116),
                            unfocusedContainerColor = Color(0xFF111116)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFFA1A1AA), modifier = Modifier.size(16.dp))
                        }
                    )

                    if (filteredApps.isEmpty()) {
                        Box(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No se encontraron aplicaciones",
                                color = Color(0xFFA1A1AA),
                                fontSize = 12.sp
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            contentPadding = PaddingValues(bottom = 8.dp)
                        ) {
                            items(filteredApps, key = { it.packageName }) { app ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF161920), RoundedCornerShape(12.dp))
                                        .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { onLaunchApp(app.packageName) }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .background(
                                                    color = Color(0xFF22D3EE).copy(alpha = 0.1f),
                                                    shape = CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = app.name.firstOrNull()?.toString()?.uppercase() ?: "",
                                                color = Color(0xFF22D3EE),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = app.name,
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = app.packageName,
                                                color = Color(0xFFA1A1AA),
                                                fontSize = 9.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFF22D3EE).copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "ABRIR",
                                            color = Color(0xFF22D3EE),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (selectedTab == 2) {
                // HISTORIAL Tab - Full command history screen view
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Historial del Asistente",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        if (commandsHistory.isNotEmpty()) {
                            Text(
                                text = "Limpiar historial",
                                fontSize = 12.sp,
                                color = Color(0xFF22D3EE),
                                modifier = Modifier.clickable { onClearHistory() }
                            )
                        }
                    }

                    if (commandsHistory.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Vacío",
                                    tint = Color(0xFF2E3036),
                                    modifier = Modifier.size(45.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No hay comandos todavía.\nDí \"$triggerWord\" o toca el micrófono para empezar.",
                                    fontSize = 13.sp,
                                    color = Color(0xFFA1A1AA),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(bottom = 8.dp)
                        ) {
                            items(commandsHistory, key = { it.id }) { record ->
                                HistoryCard(record = record)
                            }
                        }
                    }
                }
            } else if (selectedTab == 3) {
                // AUTOMACIONES Tab
                var automTab by remember { mutableStateOf(0) } // 0: Rutinas, 1: Macros
                
                // Form states for Routine addition
                var showAddRoutineDialog by remember { mutableStateOf(false) }
                var rName by remember { mutableStateOf("") }
                var rTime by remember { mutableStateOf("") }
                var rCommand by remember { mutableStateOf("") }

                // Form states for Macro addition
                var showAddMacroDialog by remember { mutableStateOf(false) }
                var mTrigger by remember { mutableStateOf("") }
                var mCommandsStr by remember { mutableStateOf("") }

                Column(modifier = Modifier.fillMaxSize()) {
                    // Header Sub-tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF161920), RoundedCornerShape(12.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        TabRowButton(
                            text = "Rutinas (Reloj)",
                            selected = automTab == 0,
                            onClick = { automTab = 0 },
                            modifier = Modifier.weight(1f)
                        )
                        TabRowButton(
                            text = "Macros de Comando",
                            selected = automTab == 1,
                            onClick = { automTab = 1 },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (automTab == 0) {
                        // Time-based Routines List
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Rutinas Programadas",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Se ejecutan solas a la hora indicada",
                                    fontSize = 11.sp,
                                    color = Color(0xFFA1A1AA)
                                )
                            }
                            IconButton(
                                onClick = { showAddRoutineDialog = true },
                                modifier = Modifier
                                    .background(Color(0xFF06B6D4).copy(alpha = 0.15f), CircleShape)
                                    .size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Nueva Rutina",
                                    tint = Color(0xFF22D3EE),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        if (routines.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                                    .background(Color(0xFF161920), RoundedCornerShape(12.dp))
                                    .padding(20.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No hay rutinas guardadas.\nToca '+' para programar una rutina diaria.",
                                    color = Color(0xFFA1A1AA),
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(routines, key = { it.id }) { routine ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
                                        border = borderStroke(false)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(14.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(0xFF06B6D4).copy(alpha = 0.1f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Timer,
                                                    contentDescription = "Alarma",
                                                    tint = Color(0xFF22D3EE),
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = routine.name,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White,
                                                    fontSize = 14.sp
                                                )
                                                Text(
                                                    text = "Hora: ${routine.executeTime} - Acción: \"${routine.command}\"",
                                                    fontSize = 11.sp,
                                                    color = Color(0xFFA1A1AA)
                                                )
                                            }
                                            Switch(
                                                checked = routine.isEnabled,
                                                onCheckedChange = { onToggleRoutine(routine.id, it) },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = Color(0xFF06B6D4),
                                                    checkedTrackColor = Color(0xFF00363F)
                                                )
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            IconButton(
                                                onClick = { onDeleteRoutine(routine.id) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Borrar",
                                                    tint = Color(0xFFEF4444).copy(alpha = 0.8f),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // Custom Command Macros List
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Macros de Voz",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Ejecutan una lista de acciones al decir la frase",
                                    fontSize = 11.sp,
                                    color = Color(0xFFA1A1AA)
                                )
                            }
                            IconButton(
                                onClick = { showAddMacroDialog = true },
                                modifier = Modifier
                                    .background(Color(0xFF06B6D4).copy(alpha = 0.15f), CircleShape)
                                    .size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Nuevo Macro",
                                    tint = Color(0xFF22D3EE),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        if (customMacros.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                                    .background(Color(0xFF161920), RoundedCornerShape(12.dp))
                                    .padding(20.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No hay macros guardados.\nToca '+' para añadir secuencias personalizadas.",
                                    color = Color(0xFFA1A1AA),
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(customMacros, key = { it.id }) { macro ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
                                        border = borderStroke(false)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(14.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(0xFF06B6D4).copy(alpha = 0.1f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.FlashOn,
                                                    contentDescription = "Macro",
                                                    tint = Color(0xFF22D3EE),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "Frase: \"${macro.triggerPhrase}\"",
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White,
                                                    fontSize = 14.sp
                                                )
                                                Text(
                                                    text = "Pasos: ${macro.commands.joinToString(" -> ") { "\"$it\"" }}",
                                                    fontSize = 11.sp,
                                                    color = Color(0xFFA1A1AA)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Switch(
                                                checked = macro.isEnabled,
                                                onCheckedChange = { onToggleCustomMacro(macro.id, it) },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = Color(0xFF06B6D4),
                                                    checkedTrackColor = Color(0xFF00363F)
                                                )
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            IconButton(
                                                onClick = { onDeleteCustomMacro(macro.id) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Borrar",
                                                    tint = Color(0xFFEF4444).copy(alpha = 0.8f),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Add Routine Dialog
                if (showAddRoutineDialog) {
                    AlertDialog(
                        onDismissRequest = { showAddRoutineDialog = false },
                        containerColor = Color(0xFF1D1F24),
                        title = { Text("Añadir Rutina Diaria", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = rName,
                                    onValueChange = { rName = it },
                                    label = { Text("Nombre (ej: Resumen tarde)", color = Color.Gray) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFF06B6D4),
                                        unfocusedBorderColor = Color(0xFF2C2C35)
                                    )
                                )
                                OutlinedTextField(
                                    value = rTime,
                                    onValueChange = { rTime = it },
                                    label = { Text("Hora (Formato HH:MM, ej: 15:00)", color = Color.Gray) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFF06B6D4),
                                        unfocusedBorderColor = Color(0xFF2C2C35)
                                    )
                                )
                                OutlinedTextField(
                                    value = rCommand,
                                    onValueChange = { rCommand = it },
                                    label = { Text("Comando de voz a ejecutar autom.", color = Color.Gray) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFF06B6D4),
                                        unfocusedBorderColor = Color(0xFF2C2C35)
                                    )
                                )
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    if (rName.isNotBlank() && rTime.isNotBlank() && rCommand.isNotBlank()) {
                                        onAddRoutine(rName, rTime, rCommand)
                                        rName = ""
                                        rTime = ""
                                        rCommand = ""
                                        showAddRoutineDialog = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06B6D4))
                            ) {
                                Text("Guardar", color = Color.Black)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showAddRoutineDialog = false }) {
                                Text("Cancelar", color = Color.Gray)
                            }
                        }
                    )
                }

                // Add Custom Macro Dialog
                if (showAddMacroDialog) {
                    AlertDialog(
                        onDismissRequest = { showAddMacroDialog = false },
                        containerColor = Color(0xFF1D1F24),
                        title = { Text("Añadir Macro (Secuencia)", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = mTrigger,
                                    onValueChange = { mTrigger = it },
                                    label = { Text("Frase disparadora (ej: modo juego)", color = Color.Gray) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFF06B6D4),
                                        unfocusedBorderColor = Color(0xFF2C2C35)
                                    )
                                )
                                OutlinedTextField(
                                    value = mCommandsStr,
                                    onValueChange = { mCommandsStr = it },
                                    label = { Text("Comandos (uno por línea o separados por comas)", color = Color.Gray) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFF06B6D4),
                                        unfocusedBorderColor = Color(0xFF2C2C35)
                                    )
                                )
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    if (mTrigger.isNotBlank() && mCommandsStr.isNotBlank()) {
                                        val cmdList = mCommandsStr.split("\n", ",").map { it.trim() }.filter { it.isNotEmpty() }
                                        if (cmdList.isNotEmpty()) {
                                            onAddCustomMacro(mTrigger, cmdList)
                                            mTrigger = ""
                                            mCommandsStr = ""
                                            showAddMacroDialog = false
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06B6D4))
                            ) {
                                Text("Guardar", color = Color.Black)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showAddMacroDialog = false }) {
                                Text("Cancelar", color = Color.Gray)
                            }
                        }
                    )
                }
            }
        }

            // Bottom Navigation (Material 3 premium translucent glass style)
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1D1F24).copy(alpha = 0.6f), RoundedCornerShape(24.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(24.dp))
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Home (0) Tab
                Column(
                    modifier = Modifier
                        .clickable { selectedTab = 0 }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(64.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (selectedTab == 0) Color(0xFFD0E4FF) else Color.Transparent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Inicio",
                            tint = if (selectedTab == 0) Color(0xFF001D36) else Color.White.copy(alpha = 0.5f)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "INICIO",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == 0) Color(0xFFD0E4FF) else Color.White.copy(alpha = 0.5f)
                    )
                }

                // Apps (1) Tab
                Column(
                    modifier = Modifier
                        .clickable { selectedTab = 1 }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(64.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (selectedTab == 1) Color(0xFFD0E4FF) else Color.Transparent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Apps,
                            contentDescription = "Aplicaciones",
                            tint = if (selectedTab == 1) Color(0xFF001D36) else Color.White.copy(alpha = 0.5f)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "APPS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == 1) Color(0xFFD0E4FF) else Color.White.copy(alpha = 0.5f)
                    )
                }

                // History (2) Tab
                Column(
                    modifier = Modifier
                        .clickable { selectedTab = 2 }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(64.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (selectedTab == 2) Color(0xFFD0E4FF) else Color.Transparent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Historial",
                            tint = if (selectedTab == 2) Color(0xFF001D36) else Color.White.copy(alpha = 0.5f)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "HISTORIAL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == 2) Color(0xFFD0E4FF) else Color.White.copy(alpha = 0.5f)
                    )
                }

                // Automations (3) Tab
                Column(
                    modifier = Modifier
                        .clickable { selectedTab = 3 }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(64.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (selectedTab == 3) Color(0xFFD0E4FF) else Color.Transparent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Automaciones",
                            tint = if (selectedTab == 3) Color(0xFF001D36) else Color.White.copy(alpha = 0.5f)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "AUTOS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == 3) Color(0xFFD0E4FF) else Color.White.copy(alpha = 0.5f)
                    )
                }

                // Decorative Music Tab per HTML design spec
                Column(
                    modifier = Modifier
                        .clickable { 
                            selectedTab = 0
                            onSendTextCommand("Pon música relajante")
                        }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(64.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = "Música",
                            tint = Color.White.copy(alpha = 0.5f)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "MÚSICA",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.5f)
                    )
                }

                // Decorative Profile/Settings Tab per HTML design spec
                Column(
                    modifier = Modifier
                        .clickable { showSettings = true }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(64.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Perfil",
                            tint = Color.White.copy(alpha = 0.5f)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "PERFIL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.5f)
                    )
                }
            }
        }

    // Modal Settings Dialog
    if (showSettings) {
        SettingsDialog(
            currentWord = triggerWord,
            currentWebhook = discordWebhook,
            ttsEnabled = ttsEnabled,
            onDismiss = { showSettings = false },
            onSave = { word, webhook, tts ->
                onUpdateTriggerWord(word)
                onUpdateDiscordWebhook(webhook)
                onToggleTts(tts)
                showSettings = false
            }
        )
    }

    // Modal Add Shortcut Dialog
    if (showAddShortcutDialog) {
        AlertDialog(
            onDismissRequest = { showAddShortcutDialog = false },
            title = { Text("Nuevo Atajo de Voz", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Ingresa la frase de activación (ej: 'clase de ingles') y el enlace de destino (ej: un link de Google Meet). Al decir esta frase, el asistente la abrirá directamente.",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    OutlinedTextField(
                        value = newShortcutKey,
                        onValueChange = { newShortcutKey = it },
                        label = { Text("Frase de Activación", color = Color.Gray) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF06B6D4)
                        )
                    )
                    OutlinedTextField(
                        value = newShortcutUrl,
                        onValueChange = { newShortcutUrl = it },
                        label = { Text("URL / Enlace de Internet", color = Color.Gray) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF06B6D4)
                        ),
                        placeholder = { Text("https://meet.google.com/...", color = Color.DarkGray, fontSize = 11.sp) }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newShortcutKey.isNotBlank() && newShortcutUrl.isNotBlank()) {
                            onAddVoiceShortcut(newShortcutKey, newShortcutUrl)
                            newShortcutKey = ""
                            newShortcutUrl = ""
                            showAddShortcutDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06B6D4))
                ) {
                    Text("Guardar", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddShortcutDialog = false }) {
                    Text("Cancelar", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF1D1F24),
            shape = RoundedCornerShape(24.dp)
        )
    }
}

@Composable
fun borderStroke(isActive: Boolean): androidx.compose.foundation.BorderStroke {
    val targetColor = if (isActive) Color(0xFF06B6D4) else Color(0xFF2C2C3A)
    val color by animateColorAsState(targetValue = targetColor, animationSpec = tween(400))
    return androidx.compose.foundation.BorderStroke(1.dp, color)
}

@Composable
fun HistoryCard(record: com.example.model.CommandRecord) {
    val format = SimpleDateFormat("HH:mm", Locale.getDefault())
    val formattedTime = format.format(Date(record.timestamp))

    val iconPair = when (record.parsedAction) {
        "Enviar Correo" -> Icons.Default.Email to Color(0xFF2EC4B6)
        "Poner Alarma" -> Icons.Default.Notifications to Color(0xFF06B6D4)
        "Música" -> Icons.Default.PlayArrow to Color(0xFF22D3EE)
        "Discord Webhook" -> Icons.Default.Chat to Color(0xFF3B82F6)
        "Crear Nota" -> Icons.Default.Notes to Color(0xFFFACC15)
        "Abrir Mapa" -> Icons.Default.Map to Color(0xFFF87171)
        "Llamar Contacto" -> Icons.Default.Call to Color(0xFF4ADE80)
        "Abrir Aplicación" -> Icons.Default.Launch to Color(0xFFA78BFA)
        "Traducción" -> Icons.Default.Translate to Color(0xFF22D3EE)
        "Buscar en Web" -> Icons.Default.Search to Color(0xFFFBBF24)
        "Clima" -> Icons.Default.WbSunny to Color(0xFFFB923C)
        "Cuenta Atrás" -> Icons.Default.Timer to Color(0xFFF87171)
        "Calculadora por Voz" -> Icons.Default.Calculate to Color(0xFF34D399)
        "Atajo de Voz" -> Icons.Default.Link to Color(0xFF22D3EE)
        else -> Icons.Default.Chat to Color.LightGray
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1D1F24)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(iconPair.second.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = iconPair.first,
                            contentDescription = record.parsedAction,
                            tint = iconPair.second,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = record.parsedAction,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Text(
                    text = formattedTime,
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "\"${record.rawText}\"",
                fontSize = 14.sp,
                color = Color.White,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = record.speechReply,
                fontSize = 12.sp,
                color = Color.LightGray,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun SettingsDialog(
    currentWord: String,
    currentWebhook: String,
    ttsEnabled: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, String, Boolean) -> Unit
) {
    var word by remember { mutableStateOf(currentWord) }
    var webhook by remember { mutableStateOf(currentWebhook) }
    var tts by remember { mutableStateOf(ttsEnabled) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(16.dp, RoundedCornerShape(24.dp)),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1D1F24))
        ) {
            Column(
                modifier = Modifier
                    .padding(22.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Ajustes del Asistente",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Trigger word settings
                OutlinedTextField(
                    value = word,
                    onValueChange = { word = it },
                    label = { Text("Palabra de Activación", color = Color.Gray) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF06B6D4),
                        unfocusedBorderColor = Color(0xFF323246),
                        focusedContainerColor = Color(0xFF12121A)
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Discord Webhook settings
                OutlinedTextField(
                    value = webhook,
                    onValueChange = { webhook = it },
                    label = { Text("Webhook de Discord (Opcional)", color = Color.Gray) },
                    singleLine = true,
                    placeholder = { Text("https://discord.com/api/webhooks/...", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF06B6D4),
                        unfocusedBorderColor = Color(0xFF323246),
                        focusedContainerColor = Color(0xFF12121A)
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Text To Speech toggle option
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Voz del Asistente (TTS)",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Switch(
                        checked = tts,
                        onCheckedChange = { tts = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF06B6D4),
                            checkedTrackColor = Color(0xFF00363F)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))
                
                // Security Key Warning per skill directive guidelines!
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0A1220), RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Keys",
                            tint = Color(0xFF3B82F6),
                            modifier = Modifier.size(20.dp).padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Seguridad: Tus claves API se inyectan localmente mediante BuildConfig. No compartas capturas ni APKs de producción con claves secretas activas.",
                            color = Color(0xFFD0E4FF),
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancelar", color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = { onSave(word, webhook, tts) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06B6D4))
                    ) {
                        Text("Guardar", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SelectedImagePreview(
    bitmap: android.graphics.Bitmap?,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (bitmap != null) {
        Box(
            modifier = modifier
                .padding(bottom = 12.dp)
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1D1F24))
                .border(1.dp, Color(0xFF06B6D4).copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Selected image preview",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            
            // Subtle dark overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f))))
            )
            
            // Title
            Text(
                text = "Imagen cargada para Vox AI",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
            )

            // Close button
            IconButton(
                onClick = onClear,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(28.dp)
                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Clear image",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun TabRowButton(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) Color(0xFF06B6D4) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (selected) Color.Black else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}
