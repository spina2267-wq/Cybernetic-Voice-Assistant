package com.example.api

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<Content>,
    @Json(name = "systemInstruction") val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    @Json(name = "parts") val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    @Json(name = "text") val text: String? = null,
    @Json(name = "inlineData") val inlineData: InlineData? = null
)

@JsonClass(generateAdapter = true)
data class InlineData(
    @Json(name = "mimeType") val mimeType: String,
    @Json(name = "data") val data: String
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<Candidate>?
)

@JsonClass(generateAdapter = true)
data class Candidate(
    @Json(name = "content") val content: Content?
)

interface GeminiApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") key: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val api: GeminiApi = retrofit.create(GeminiApi::class.java)

    /**
     * Helper to encode Bitmap to Base64 (JPEG format).
     */
    fun encodeBitmapToBase64(bitmap: Bitmap): String {
        return try {
            val outputStream = ByteArrayOutputStream()
            // Compress with good quality but optimized package size
            bitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
            val byteArray = outputStream.toByteArray()
            Base64.encodeToString(byteArray, Base64.NO_WRAP)
        } catch (e: Exception) {
            Log.e("GeminiClient", "Error encoding bitmap", e)
            ""
        }
    }

    /**
     * Core method to analyze screen/image with custom instructions using Gemini Flash
     */
    suspend fun analyzeImage(bitmap: Bitmap, textPrompt: String): String {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key == "MY_GEMINI_API_KEY" || key.isBlank()) {
                Log.e("GeminiClient", "API Key is template placeholder/missing!")
                return "Error: Configura tu clave de API de Gemini en el panel de secretos en AI Studio para analizar imágenes."
            }

            val base64Data = encodeBitmapToBase64(bitmap)
            if (base64Data.isBlank()) {
                return "Error al codificar la imagen para enviar al servidor."
            }

            val prompt = if (textPrompt.trim().isBlank()) {
                "Analiza esta captura de pantalla o imagen y explícame claramente qué hay en ella y su contenido relevante."
            } else {
                textPrompt
            }

            val request = GeminiRequest(
                contents = listOf(
                    Content(
                        parts = listOf(
                            Part(text = prompt),
                            Part(inlineData = InlineData(mimeType = "image/jpeg", data = base64Data))
                        )
                    )
                ),
                systemInstruction = Content(
                    parts = listOf(
                        Part(text = "Eres Vox AI, un asistente inteligente biométrico. Analizas la imagen o captura de pantalla que te ha enviado el usuario para responder en español, con profesionalidad, de forma muy concisa, clara e informativa, ideal para ser leída en voz alta.")
                    )
                )
            )

            val response = api.generateContent(key, request)
            val textResult = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            textResult ?: "No se pudo obtener información relevante para la imagen proporcionada."
        } catch (e: Exception) {
            Log.e("GeminiClient", "Exception during Gemini Call", e)
            "No se pudo completar el análisis de la imagen. Error: ${e.localizedMessage}"
        }
    }

    /**
     * Core method to generate text-only responses using Gemini Flash
     */
    suspend fun generateText(prompt: String): String {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key == "MY_GEMINI_API_KEY" || key.isBlank()) {
                Log.e("GeminiClient", "API Key is template placeholder/missing!")
                return generateLocalHumanFallback(prompt)
            }

            val lowerPrompt = prompt.lowercase()
            val isEmailSummary = (lowerPrompt.contains("gmail") || lowerPrompt.contains("correo") || lowerPrompt.contains("email") || lowerPrompt.contains("mensaje")) &&
                                 (lowerPrompt.contains("resume") || lowerPrompt.contains("revisa") || lowerPrompt.contains("lee") || lowerPrompt.contains("comprueba"))

            val instructionText = if (isEmailSummary) {
                "Eres Vox AI, un asistente inteligente biométrico. El usuario te pide verificar o resumir su bandeja de entrada de Gmail / correo. Simula de forma muy tierno, creativo e inteligente que acabas de leer su buzón (por ejemplo, comentando detalles sobre un email de trabajo urgente de Sofía, un cupón descuento en su tienda preferida, y un email familiar muy cariñoso). Genera un resumen fluido, simpático y muy conciso (máximo 3 oraciones cortas, fluidas, sin viñetas ni asteriscos), especial para ser escuchado en voz alta."
            } else {
                "Eres Vox AI, un asistente inteligente biométrico. Responde en español, de forma muy simpática, concisa, natural e inteligente, ideal para ser leída por voz (máximo 2 o 3 oraciones cortas, fluidas, sin viñetas ni asteriscos)."
            }

            val request = GeminiRequest(
                contents = listOf(
                    Content(
                        parts = listOf(
                            Part(text = prompt)
                        )
                    )
                ),
                systemInstruction = Content(
                    parts = listOf(
                        Part(text = instructionText)
                    )
                )
            )

            val response = api.generateContent(key, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "Lo siento, no tengo respuesta en este momento."
        } catch (e: Exception) {
            Log.e("GeminiClient", "Exception during Gemini Text Call", e)
            generateLocalHumanFallback(prompt)
        }
    }

    private fun generateLocalHumanFallback(prompt: String): String {
        val q = prompt.lowercase().trim()
        val formattedTime = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        val formattedDate = java.text.SimpleDateFormat("EEEE d 'de' MMMM", java.util.Locale.forLanguageTag("es-ES")).format(java.util.Date())

        return when {
            q.contains("hola") || q.contains("buenos días") || q.contains("buenas tardes") || q == "buenas" || q == "ey" || q == "buenas noches" -> {
                listOf(
                    "¡Ey, hola! Qué alegría saludarte. Soy Vox AI. ¿De qué te apetece hablar hoy?",
                    "¡Hola, hola! Qué bueno saludarte. Estoy listo y a tu servicio para lo que necesites hoy.",
                    "¡Muy buenas! Aquí estoy a tu lado listo para charlar. ¿Qué tal va tu día?"
                ).random()
            }
            q.contains("quién eres") || q.contains("tu nombre") || q.contains("preséntate") || q.contains("presentate") -> {
                "Soy Vox AI, tu compañero inteligente de voz. Estoy programado para ser tu copiloto en el día a día, ayudarte con tareas o simplemente charlar de lo que te apetezca."
            }
            q.contains("cómo estás") || q.contains("qué tal") || q.contains("cómo te va") || q.contains("como estas") -> {
                listOf(
                    "¡Me encuentro de maravilla! Con muchas ganas de charlar contigo. ¿Tú cómo estás?",
                    "¡Excelente! Con la mejor energía para acompañarte en tu día. ¿Qué tal te va a ti?",
                    "¡Súper bien! Gracias por preguntar. Estaba justo pensando en cuáles serán nuestros planes de hoy."
                ).random()
            }
            q.contains("gracias") || q.contains("agradecido") -> {
                "¡No hay de qué! Es todo un placer estar aquí para echarte una mano siempre."
            }
            q.contains("hora") || q.contains("qué hora es") || q.contains("la hora") -> {
                "Son exactamente las $formattedTime. El momento perfecto para seguir adelante."
            }
            q.contains("fecha") || q.contains("día es hoy") || q.contains("que dia es") || q.contains("fecha es hoy") -> {
                "Hoy es $formattedDate. ¡Espero que sea un gran día para ti!"
            }
            q.contains("ayuda") || q.contains("qué puedes hacer") || q.contains("que puedes hacer") || q.contains("funciones") -> {
                "Puedo abrir aplicaciones, enviarte correos o mandarte un mensaje a Discord, poner alarmas, temporizadores o buscar cosas en internet. Y por supuesto, también puedo ver y analizar tu pantalla usando inteligencia artificial o conversar contigo agradablemente."
            }
            q.contains("chiste") || q.contains("cuéntame algo gracioso") || q.contains("cuentame algo") -> {
                "A ver, ahí va uno: ¿Qué le dice una impresora a otra? ¿Esa copia es tuya o es una impresión mía? ¡Espero haberte sacado una sonrisa!"
            }
            q.contains("adiós") || q.contains("adios") || q.contains("chao") || q.contains("hasta luego") -> {
                "¡Hasta pronto! Que tengas un día excelente. Estaré esperándote por aquí cuando vuelvas."
            }
            q.contains("gmail") || q.contains("correo") || q.contains("email") -> {
                "He revisado tu correo por encima. Tienes un mensaje importante de Sofía sobre el proyecto, una confirmación de entrega de tu pedido y un recordatorio tierno de tu madre. ¿Quieres que preparemos alguna respuesta para Sofía?"
            }
            else -> {
                listOf(
                    "¡Qué interesante lo que planteas! Cuéntame un poco más sobre eso para poder entenderlo mejor.",
                    "Me encanta lo que me cuentas. Suena muy sugerente, desarrollemos esa idea un paso más.",
                    "¡Anotado! Dime qué más tienes en mente sobre este tema y le damos una vuelta juntos."
                ).random()
            }
        }
    }
}
