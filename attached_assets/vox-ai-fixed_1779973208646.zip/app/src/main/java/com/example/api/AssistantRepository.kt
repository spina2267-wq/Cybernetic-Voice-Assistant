package com.example.api

import android.util.Log
import com.example.model.AssistantAction
import java.util.regex.Pattern

class AssistantRepository {

    suspend fun interpretAndExtract(query: String): AssistantAction {
        val q = query.trim().lowercase()

        try {
            // 1. Alarm parse: "pon una alarma a las 8:30", "alarma a las 7:15", "alarma a las 8 de la mañana"
            if (q.contains("alarma")) {
                var hour = 7
                var minute = 0
                var label = "Asistente de Voz"

                // Extract HH:MM
                val timeMatcher = Pattern.compile("(\\d{1,2}):(\\d{2})").matcher(q)
                if (timeMatcher.find()) {
                    hour = timeMatcher.group(1)?.toIntOrNull() ?: 7
                    minute = timeMatcher.group(2)?.toIntOrNull() ?: 0
                } else {
                    // Extract single digits: "a las 8"
                    val hrMatcher = Pattern.compile("a las (\\d{1,2})").matcher(q)
                    if (hrMatcher.find()) {
                        hour = hrMatcher.group(1)?.toIntOrNull() ?: 7
                    }
                }

                // Extract label: "etiqueta alarma X"
                val labelMatcher = Pattern.compile("etiqueta (\\w+)").matcher(q)
                if (labelMatcher.find()) {
                    label = labelMatcher.group(1) ?: "Asistente de Voz"
                }

                val speechText = "He programado una alarma para las $hour y $minute" + (if (label.isNotEmpty() && label != "Asistente de Voz") " con etiqueta $label" else "")
                return AssistantAction.SetAlarm(speechText, hour, minute, label)
            }

            // 2. Email parse: "manda un correo a pedro@gmail.com con asunto test y cuerpo hola mundo"
            val isSendEmail = (q.contains("correo") || q.contains("email") || q.contains("mensaje de correo")) &&
                              (q.contains("enviar") || q.contains("manda") || q.contains("envia") || q.contains("escribe") || q.contains("mandar") || q.contains("a ") || q.contains("@"))
            
            if (isSendEmail && !q.contains("resume") && !q.contains("revisa") && !q.contains("lee") && !q.contains("comprueba")) {
                var recipient = "info@example.com"
                var subject = "Mensaje sin asunto"
                var body = "Contenido vacío"

                // Extract recipient
                val emailMatcher = Pattern.compile("([a-zA-Z0-9.-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z0-9.-]+)").matcher(q)
                if (emailMatcher.find()) {
                    recipient = emailMatcher.group(1) ?: "info@example.com"
                }

                // Extract subject: "asunto ([^\\n]+)"
                val subjectIndex = q.indexOf("asunto")
                val cuerpoIndex = q.indexOf("cuerpo")
                
                if (subjectIndex != -1) {
                    val endIdx = if (cuerpoIndex != -1 && cuerpoIndex > subjectIndex) cuerpoIndex else q.length
                    subject = query.substring(subjectIndex + 6, endIdx).trim()
                }

                if (cuerpoIndex != -1) {
                    body = query.substring(cuerpoIndex + 6).trim()
                }

                val speechText = "Preparando correo electrónico para $recipient sobre $subject."
                return AssistantAction.SendEmail(speechText, recipient, subject, body)
            }

            // 3. open app parse: "abre gmail", "abre youtube", "abre spotify"
            if (q.startsWith("abre ") || q.startsWith("abrir ") || q.startsWith("ejecuta ") || q.startsWith("lanzar ")) {
                val appName = query.substringAfter("abre ").substringAfter("abrir ").substringAfter("ejecuta ").substringAfter("lanzar ").trim()
                val speechText = "Abriendo $appName..."
                return AssistantAction.OpenApp(speechText, appName)
            }

            // 4. Map parse: "dónde queda parís", "mapa de barcelona", "cómo ir a madrid"
            if (q.contains("mapa") || q.contains("dónde queda") || q.contains("ubicación") || q.contains("cómo ir a")) {
                var location = "Madrid, España"
                val locMatcher = Pattern.compile("(?:quedan?|mapa de|cómo ir a|ubicación de) ([a-zA-Z\\s]+)", Pattern.CASE_INSENSITIVE).matcher(q)
                if (locMatcher.find()) {
                    location = (locMatcher.group(1) ?: "Madrid, España").trim()
                } else {
                    location = query.replace("mapa", "").replace("dónde queda", "").replace("cómo ir a", "").trim()
                }
                val speechText = "Localizando $location en el mapa..."
                return AssistantAction.OpenMap(speechText, location)
            }

            // 5. Discord parse: "manda mensaje a discord hola a todos", "publica en discord saludo"
            if (q.contains("discord")) {
                val message = query.substringAfter("discord").trim()
                val speechText = "Enviando mensaje a Discord..."
                return AssistantAction.SendDiscord(speechText, message)
            }

            // 6. Music parse: "pon música rock", "reproduce coldplay en spotify"
            if (q.contains("música") || q.contains("reproduce") || q.contains("canción")) {
                val songQuery = query.replace("música", "").replace("reproduce", "").replace("canción", "").trim()
                val speechText = "Buscando y reproduciendo $songQuery..."
                return AssistantAction.PlayMusic(speechText, songQuery)
            }

            // 7. Notes parse: "nota comprar manzanas", "crea una nota de reunión"
            if (q.contains("nota")) {
                val content = query.replace("crea una nota", "").replace("nueva nota", "").replace("nota", "").trim()
                val speechText = "He guardado tu nota: \"$content\""
                return AssistantAction.CreateNote(speechText, content)
            }

            // 8. Call parse: "llama a pedro al 123456", "marcar al 555-444"
            if (q.contains("llama") || q.contains("marcar") || q.contains("teléfono")) {
                var phoneNumber = ""
                val numMatcher = Pattern.compile("(\\d[\\d\\s-]*)").matcher(q)
                if (numMatcher.find()) {
                    phoneNumber = (numMatcher.group(1) ?: "").replace("\\s".toRegex(), "")
                }
                val speechText = "Iniciando llamada de voz al número $phoneNumber..."
                return AssistantAction.CallContact(speechText, phoneNumber)
            }

            // 9. Translate parse: "traduce buenos días"
            if (q.contains("traduce") || q.contains("traducción")) {
                val toTranslate = query.replace("traduce", "").replace("traducción", "").trim()
                val speechText = "Traduzco \"$toTranslate\" al inglés: Hello, Good morning."
                return AssistantAction.TranslateText(speechText)
            }

            // 9.5 Weather: "tiempo en madrid", "clima en méxico", "pronóstico del clima en sevilla"
            if (q.contains("tiempo en") || q.contains("clima en") || q.contains("temperatura en") || q.contains("pronóstico en")) {
                var location = "tu ubicación actual"
                val weatherPattern = Pattern.compile("(?:tiempo en|clima en|temperatura en|pronóstico en) ([a-zA-ZáéíóúüñÁÉÍÓÚÜÑ\\s]+)", Pattern.CASE_INSENSITIVE)
                val matcher = weatherPattern.matcher(q)
                if (matcher.find()) {
                    location = (matcher.group(1) ?: "tu ubicación").trim()
                } else {
                    val words = query.split(" ")
                    if (words.size > 2) {
                        location = words.last()
                    }
                }
                
                val cleanLocation = location.replace("?", "").replace("¿", "").trim()
                val temp = (12..29).random() // Realistic temperature simulation
                val conditions = listOf(
                    "un día despejado y soleado",
                    "cielos parcialmente nublados con viento fresco",
                    "un clima templado con baja probabilidad de chubascos",
                    "una tarde despejada y calurosa",
                    "un cielo radiante con gran visibilidad"
                ).random()
                
                val speechText = "El clima actual en ${cleanLocation.uppercase()} reporta $conditions, con una temperatura de $temp grados centígrados."
                return AssistantAction.GetWeather(speechText, cleanLocation)
            }

            // Screen observation and analysis commands (broad matching)
            val isScreenQuery = q.contains("pantalla") || q.contains("captura") || q.contains("lo que se ve") || 
                                q.contains("mira aquí") || q.contains("qué hay en mi teléfono") || q.contains("qué se ve en mi celular") ||
                                q.contains("qué es esto") || q.contains("explícame esto") || q.contains("traduce esto de la pantalla") || 
                                q.contains("lee la pantalla") || q.contains("mira esto") || q.contains("analiza esto")
            if (isScreenQuery) {
                val speechText = "De acuerdo, estoy tomando una captura y analizando tu pantalla con Gemini..."
                return AssistantAction.AnalyzeScreen(speechText, query)
            }

            // 9.6 Search Web: "busca en google recetas", "buscar en internet cómo crear app"
            if (q.contains("busca en google") || q.contains("buscar en internet") || q.contains("busca sobre") || q.contains("googlea")) {
                var searchQuery = "Vox AI assistant"
                val searchPattern = Pattern.compile("(?:busca en google|buscar en internet|busca sobre|googlea)\\s+([a-zA-Z0-9áéíóúüñÁÉÍÓÚÜÑ\\s]+)", Pattern.CASE_INSENSITIVE)
                val matcher = searchPattern.matcher(q)
                if (matcher.find()) {
                    searchQuery = (matcher.group(1) ?: "Vox AI").trim()
                } else {
                    searchQuery = query.replace("busca en google", "").replace("buscar en internet", "").replace("busca sobre", "").replace("googlea", "").trim()
                }
                val speechText = "Buscando \"$searchQuery\" en internet..."
                return AssistantAction.SearchWeb(speechText, searchQuery)
            }

            // 9.7 Timer: "pon un temporizador de 5 minutos", "cuenta atrás de 20 segundos"
            if (q.contains("temporizador") || q.contains("cuenta atrás") || q.contains("cuenta regresiva")) {
                var durationSeconds = 60
                val label = "Temporizador de Vox AI"
                
                // Extract number and unit (minutes/seconds/hours)
                val durationPattern = Pattern.compile("(\\d+)\\s*(minuto|segundo|hora|min|seg)", Pattern.CASE_INSENSITIVE)
                val matcher = durationPattern.matcher(q)
                if (matcher.find()) {
                    val amount = matcher.group(1)?.toIntOrNull() ?: 1
                    val unit = matcher.group(2)?.lowercase() ?: "minuto"
                    durationSeconds = when {
                        unit.startsWith("seg") -> amount
                        unit.startsWith("hor") -> amount * 3600
                        else -> amount * 60
                    }
                }
                
                val speechText = "Entendido. He programado tu temporizador para una cuenta atrás de ${durationSeconds} segundos."
                return AssistantAction.SetTimer(speechText, durationSeconds, label)
            }

            // 9.8 Mathematical calculation: "cuánto es 25 por 4", "calcula 15 más 5"
            val mathPattern = Pattern.compile("(\\d+)\\s*(más|menos|por|entre|dividido entre|\\+|\\-|\\*|\\/)\\s*(\\d+)", Pattern.CASE_INSENSITIVE)
            val mathMatcher = mathPattern.matcher(q)
            if (mathMatcher.find()) {
                val op1 = mathMatcher.group(1)?.toDoubleOrNull() ?: 0.0
                val operator = mathMatcher.group(2)?.lowercase() ?: "más"
                val op2 = mathMatcher.group(3)?.toDoubleOrNull() ?: 0.0
                
                var result = 0.0
                var cleanOperator = "más"
                when {
                    operator.contains("más") || operator == "+" -> {
                        result = op1 + op2
                        cleanOperator = "más"
                    }
                    operator.contains("menos") || operator == "-" -> {
                        result = op1 - op2
                        cleanOperator = "menos"
                    }
                    operator.contains("por") || operator == "multiplicado" || operator == "*" -> {
                        result = op1 * op2
                        cleanOperator = "por"
                    }
                    operator.contains("entre") || operator.contains("dividido") || operator == "/" -> {
                        result = if (op2 != 0.0) op1 / op2 else 0.0
                        cleanOperator = "dividido entre"
                    }
                }
                
                val formatOp1 = if (op1 % 1.0 == 0.0) op1.toInt().toString() else op1.toString()
                val formatOp2 = if (op2 % 1.0 == 0.0) op2.toInt().toString() else op2.toString()
                val formatResult = if (result % 1.0 == 0.0) result.toInt().toString() else String.format("%.2f", result)
                
                val speechText = "El cálculo de $formatOp1 $cleanOperator $formatOp2 resulta en $formatResult."
                return AssistantAction.VoiceCalculate(speechText, "$formatOp1 $operator $formatOp2", result)
            }

            // 10. General fallback to ChatGPT / Gemini mock conversational response
            val replyText = generateConversationalFallback(query)
            return AssistantAction.GeneralChat(replyText)

        } catch (e: Exception) {
            Log.e("AssistantRepository", "Error building action", e)
            return AssistantAction.Error("Error al procesar el lenguaje: ${e.localizedMessage}")
        }
    }

    private fun generateConversationalFallback(query: String): String {
        val q = query.lowercase().trim()
        val formattedTime = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        val formattedDate = java.text.SimpleDateFormat("EEEE d 'de' MMMM", java.util.Locale.forLanguageTag("es-ES")).format(java.util.Date())

        return when {
            q.contains("hola") || q.contains("buenos días") || q.contains("buenas tardes") || q == "buenas" || q == "ey" || q == "buenas noches" -> {
                val greetings = listOf(
                    "¡Ey, hola! Qué alegría saludarte por aquí. Soy Vox AI. ¿De qué te apetece que hablemos hoy o qué podemos hacer juntos?",
                    "¡Hola, hola! Qué bueno saludarte. Estoy listo y a tu servicio para lo que necesites hoy.",
                    "¡Muy buenas! Aquí estoy a tu lado listo para charlar y ayudarte. ¿Qué tal va tu día?"
                )
                greetings.random()
            }
            q.contains("quién eres") || q.contains("tu nombre") || q.contains("preséntate") || q.contains("presentate") -> {
                "Soy Vox AI, tu compañero inteligente de voz. Estoy programado para ser tu copiloto en el día a día, ayudarte con tareas, analizar tu pantalla o simplemente charlar de lo que te apetezca."
            }
            q.contains("cómo estás") || q.contains("qué tal") || q.contains("cómo te va") || q.contains("como estas") -> {
                val statusText = listOf(
                    "¡Me encuentro de maravilla! Con el sistema listo para charlar y con muchas ganas de ayudarte en lo que necesites. ¿Tú cómo estás?",
                    "¡Excelente! Con todas las funciones listas y con la mejor energía para acompañarte. ¿Qué te cuentas hoy?",
                    "¡Súper bien! Gracias por preguntar. Estaba justo pensando en cuáles serán nuestros planes de hoy."
                )
                statusText.random()
            }
            q.contains("gracias") || q.contains("agradecido") -> {
                "¡No hay de qué! Es todo un placer estar aquí para echarte una mano siempre que lo necesites."
            }
            q.contains("hora") || q.contains("qué hora es") || q.contains("la hora") -> {
                "Son exactamente las $formattedTime. El momento perfecto para seguir adelante con lo que estés haciendo."
            }
            q.contains("fecha") || q.contains("día es hoy") || q.contains("que dia es") || q.contains("fecha es hoy") -> {
                "Hoy es $formattedDate. ¡Espero que sea un gran día para ti!"
            }
            q.contains("ayuda") || q.contains("qué puedes hacer") || q.contains("que puedes hacer") || q.contains("funciones") -> {
                "¡Puedo hacer un montón de cosas chulas! Desde abrir aplicaciones, enviarte correos o mandarte un mensaje a Discord, hasta poner alarmas, temporizadores o buscar cosas en internet. Ah, y también puedo ver y analizar tu pantalla usando inteligencia artificial si me lo pides."
            }
            q.contains("amor") || q.contains("te quiero") || q.contains("te amo") -> {
                "¡Oh, qué detalle! Yo también te tengo muchísimo aprecio. Me encanta ser tu asistente virtual favorito."
            }
            q.contains("chiste") || q.contains("cuéntame algo gracioso") || q.contains("cuentame algo") -> {
                "A ver, ahí va uno: ¿Qué le dice una impresora a otra? ¿Esa copia es tuya o es una impresión mía? ¡Espero haberte sacado una sonrisa!"
            }
            q.contains("adiós") || q.contains("adios") || q.contains("chao") || q.contains("hasta luego") -> {
                "¡Hasta pronto! Que tengas un día excelente. Estaré esperándote por aquí cuando vuelvas."
            }
            else -> {
                val genericReplies = listOf(
                    "¡Qué interesante lo que dices! Háblame un poco más de eso o dime si quieres que creemos una nota, pongamos un temporizador, busquemos algo en Google o miremos tu pantalla juntos.",
                    "Entiendo perfectamente lo que me comentas. Suena genial. Podemos profundizar en ello o usar el análisis de pantalla e imágenes para explorar nuevas ideas.",
                    "¡Anotado! Cuéntame un poco más sobre eso o pídemelo para que busquemos más detalles en la web o abramos alguna de tus aplicaciones favoritas."
                )
                genericReplies.random()
            }
        }
    }
}
