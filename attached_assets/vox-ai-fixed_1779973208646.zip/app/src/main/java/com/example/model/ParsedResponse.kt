package com.example.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ParsedResponse(
    val status: String,
    val text: String
)
