// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
  alias(libs.plugins.android.application) apply false
  alias(libs.plugins.kotlin.compose) apply false
  alias(libs.plugins.google.devtools.ksp) apply false
  alias(libs.plugins.roborazzi) apply false
  alias(libs.plugins.secrets) apply false
}

abstract class CopyApkTask : DefaultTask() {
  @get:InputFile
  abstract val srcFile: RegularFileProperty

  @get:OutputFile
  abstract val destFile: RegularFileProperty

  @TaskAction
  fun perform() {
    val src = srcFile.get().asFile
    val dest = destFile.get().asFile
    if (src.exists()) {
      src.copyTo(dest, overwrite = true)
      println("APK copied successfully!")
    } else {
      println("Source APK not found at: ${src.absolutePath}")
    }
  }
}

tasks.register<CopyApkTask>("copyApkToRoot") {
  srcFile.set(layout.projectDirectory.file(".build-outputs/app-debug.apk"))
  destFile.set(layout.projectDirectory.file("Vox_AI.apk"))
}
